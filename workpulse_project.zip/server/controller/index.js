const { handleMessage,not_a_mem_handleMessage } = require("./lib/telegram");
const { errorHandler } = require("./lib/helper");
async function handler(req, method, employees,companies,projects) {
  try {
    if (method === "GET") {
      return "Telegram API";
    } else if (method === "POST") {
      const { body } = req;
      if (body && body.message) {
        const messageObj = body.message;
        await handleMessage(messageObj, employees,companies,projects); 
        return "Success";
      }
      return "Unknown Request";
    } else {
      return "Unsupported Method";
    }
  } catch (error) {
    errorHandler(error, "mainIndexHandler");
  }
}

async function not_a_mem_handler(req, method, Not_a_MemberMessage) {
  try {
    if (method === "POST") {
      const { body } = req;
      if (body && body.message) {
        const messageObj = body.message;
        await not_a_mem_handleMessage(messageObj, Not_a_MemberMessage); 
        return "Success";
      }
      return "Unknown Request";
    } else {
      return "Unsupported Method";
    }
  } catch (error) {
    errorHandler(error, "mainIndexHandler");
  }
}
module.exports = { handler,not_a_mem_handler };
