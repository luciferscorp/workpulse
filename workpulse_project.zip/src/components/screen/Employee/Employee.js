import React, { useState,useContext } from 'react'
import '../../assets/css/Home.css'
import Navbar from '../../common/Navbar'
import Pagination from '../../common/Pagination'
import EmpPopup from '../../common/EmpPopup'
import Sidebar from '../../common/Sidebar'
import { Link, useLocation } from 'react-router-dom';
import EmployeeTaskButton from './EmployeeTaskButton'
import AuthContext from '../../../context/AuthProvider'
import Footer from '../../common/footer'
function Employee() {
  const location = useLocation();

  const [fetchStatus, setfetchStatus] = useState(null);
  const { NotifyBadgeReadCount, setNotifyBadgeReadCount,
    DB_ProjectMGR_OpenTasks, setDB_ProjectMGR_OpenTasks, } = useContext(AuthContext);
  setNotifyBadgeReadCount(0);
  const callback = payload => {
    
    setfetchStatus(payload)
  }


  return (
    <>
      <div className='home-body'>
        <Navbar />
        <Sidebar role="admin" />
        <EmpPopup titles='Join Member' callback={callback} />
        {/* <EmployeeTaskButton /> */}
        <Pagination doFetch={fetchStatus} />
        <div className="report-footer">
                <Footer/>
                </div>

      </div>
    </>
  )
}

export default Employee;