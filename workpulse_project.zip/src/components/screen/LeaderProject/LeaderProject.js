import React, { useState } from 'react'
import Navbar from '../../common/Navbar'
import Sidebar from '../../common/Sidebar'
import AssignPagePopup from '../../common/AssignPagePopup'
import AssignPagination from '../../common/AssignPagination'
import LeaderProjectPagination from '../../common/LeaderProjectPagination'
import Footer from '../../common/footer'

function LeaderProject() {

  const [fetchStatus, setfetchStatus] = useState(null);

  const callback = payload => {

    setfetchStatus(payload)
  }
  return (
    <>
    <div className='home-body'>

      <Navbar />
      <Sidebar />
      {/* <AssignPagePopup title="Assign" callback={callback} /> */}
      <LeaderProjectPagination doFetch={fetchStatus}/>
      <div className="report-footer">
                <Footer/>
                </div>
    </div>
    </>
  )
}

export default LeaderProject;