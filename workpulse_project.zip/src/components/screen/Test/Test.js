import React from 'react'
import EditCompanyDetails from '../../common/EditCompanyDetails'

function Test() {
  return (
    <div>
   
       
    </div>
  )
}

export default Test