import { React, useState, useEffect, useContext, useRef } from "react";
import Navbar from "../../common/Navbar";
import Sidebar from "../../common/Sidebar";
import AuthContext from "../../../context/AuthProvider";
import { BaseUrl } from "../../env/baseurl";
import "../../assets/css/button.css";
import Footer from "../../common/footer";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import LimitedText from "../../common/LimitedText";


function DashBoardPM() {

  const decipher = (salt) => {
    const textToChars = text => text.split('').map(c => c.charCodeAt(0));
    const applySaltToChar = code => textToChars(salt).reduce((a,b) => a ^ b, code);
    return encoded => encoded.match(/.{1,2}/g)
      .map(hex => parseInt(hex, 16))
      .map(applySaltToChar)
      .map(charCode => String.fromCharCode(charCode))
      .join('');
  }
    const myDecipher =  decipher('mySecretSalt')
  
  function getItemFromLocal(localData) {
    let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
    return form_data;
    
  }
  
    let local_data = getItemFromLocal("user_crypt");
    const LoggedID = {EmployeeID: local_data.EmployeeID}

    const [ReadData, setReadData] = useState([]);
  const {
    NotifyBadgeReadCount,
    setNotifyBadgeReadCount,
    DB_ProjectMGR_OpenTasks,
    setDB_ProjectMGR_OpenTasks,
    NotificationID, setNotificationID
  } = useContext(AuthContext);

  setNotificationID(LoggedID.EmployeeID);
  setNotifyBadgeReadCount(ReadData.reduce((sum, value) => sum + (value === 0), 0));


  const [data, setdata] = useState([]);
  const [ProjectData, setProjectData] = useState([]);
  const [ProjectLeaderAssigned, setProjectLeaderAssigned] = useState([]);
  const EMPname = useRef(undefined);
  const PRJname = useRef(undefined);

  const [ProjectCreatedDate, setProjectCreatedDate] = useState([]);
  const formattedDates = ProjectCreatedDate.map((date) => {
    const [day, month, year] = date.split("/");
    return `${month}/${day}/${year}`;
  });
  const options = { year: "numeric", month: "short", day: "numeric" };
 
  const ConvertformattedDates = formattedDates.map((date) =>
    date[2] === "/" ? new Date(date).toLocaleDateString("en-IN", options) :
      new Date([date.split("/")[1].split(" ")[0].split("-")[1], date.split("/")[1].split(" ")[0].split("-")[2], date.split("/")[1].split(" ")[0].split("-")[0],].join("/")).toLocaleDateString("en-IN", options)

  );

  
  const FetchNotifyReadDATA = async () => {
    try {
        const NotifyReadDATA = { UserID: NotificationID };
        const response = await fetch("/fetchNotifyReadDATA", {
            method: "post",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
                "Content-Type": "application/json",
            },
            redirect: "follow",
            referrerPolicy: "no-referrer",
            body: JSON.stringify(NotifyReadDATA),
        });
        const { data } = await response.json();
        setReadData(data===undefined ? [] : data.map((items) => (items.IsRead)));

    } catch (error) {
        console.error("error", error);
    }
};
FetchNotifyReadDATA();

 
  useEffect(() => {
    FetchDashboard_PM_data(EMPname.current, PRJname.current);
    Fetch_PM_data();
  }, []);

  async function Fetch_PM_data() {
    try {
      const response = await fetch(BaseUrl + "getAllPRojectDATA", {
        method: "GET",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
      });
      const { data, status } = await response.json();
      setProjectData(data === null || data === undefined ? [] : status);
      setProjectLeaderAssigned(data === null || data === undefined ? [] : data.map((items) => (items.ProjectLeader)));
    } catch (error) {
      console.error("error", error);
    }
  }
  async function FetchDashboard_PM_data(EMPname, PRJname) {
    try {
      const FetchNames = { EmployeeName: EMPname, ProjectName: PRJname };
      const response = await fetch(BaseUrl + "getDashboardPMdata", {
        method: "POST",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(FetchNames),
      });
      const { data, status } = await response.json();
    
      setdata(data === null || data === undefined ? [] : data);
      setProjectCreatedDate(data.map((items) => items.CreatedOn)); 
    } catch (error) {
      console.error("error", error);
    }
  }

  return (
    <>
      <div>
        <Navbar />
        <Sidebar />
      </div>
      {ProjectData!==200 ? (
        <div className="emp-bodycontainer">
          <div className="emp-tablecontainer">
            <h2>No Data have been founded</h2>
          </div>
        </div>
      ) : (

      <div className="DB_PM_container_wrapper">
        <h3 className="dashboard-PM-Heading">Projects</h3>

        <input
          className="dashboard-PM-empnm"
          type="text"
          onChange={(e) => {
            EMPname.current = e.target.value;
            FetchDashboard_PM_data(EMPname.current, PRJname.current);
          }}
          placeholder="Member Name"
        />
        <input
          className="dashboard-PM-prjnm"
          type="text"
          onChange={(e) => {
            PRJname.current = e.target.value;
            FetchDashboard_PM_data(EMPname.current, PRJname.current);
          }}
          placeholder="Project Name"
        />

        <div className="DB_PM_container">
        {ProjectLeaderAssigned.some(element => element !== null) ?
          (data.map((arrayData, index) => (
            <div key={index}>
              <div className="dashboard-PM-wrapper">
                <div className="dashboard-PM-title">
                  <p className="dashboard-PM-title-title">
                    <strong>{arrayData.ProjectName}</strong>{" "}
                  </p>
                  <p className="dashboard-PM-title-task">
                    <strong>Open Tasks : </strong>
                    {arrayData.ProgressCount}
                  </p>
                  <p className="dashboard-PM-title-task">
                    <strong>Tasks Completed : </strong>
                    {arrayData.CompletedCount}
                  </p>
                </div>
                <div className="dashboard-PM-desc">
                <LimitedText text={arrayData.Description} limit={100} />
                </div>
                <div className="dashboard-PM-bottom-info">
                  <div className="dashboard-PM-info">
                    <p className="dashboard-PM-info-PL">
                      <strong>Team Members : </strong>
                      {arrayData.TeamMemberIDs ? arrayData.TeamMemberIDs.split(',').length : null}
                    </p>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center",
                        backgroundColor: "#FFEFF1",
                      }}
                    >
                      <AccessTimeIcon
                        sx={{
                          fontSize: "25px",
                          color: "#FC6075",

                        }}
                      />
                      <p className="dashboard-PM-info-PL"
                        style={{
                          margin: "0",
                          marginLeft: "5px",
                          color: "#FC6075",
                          backgroundColor: "#FFEFF1",
                        }}
                      >
                        Deadline : {ConvertformattedDates[index]}
                      </p>

                    </div>

                    <p className="dashboard-PM-info-PL">
                      <strong>Project Leader : </strong>
                      {arrayData.EmployeeName}
                    </p>
                  </div></div>
              </div>
            </div>
          ))) : <div className="">No Projects have been assigned yet</div>}
        </div>
      </div>)}
      <div className="report-footer">
        <Footer />
      </div>
    </>
  );
}

export default DashBoardPM;
