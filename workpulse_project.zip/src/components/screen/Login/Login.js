import '../../assets/css/LoginPage.css'
import Sidebar from '../../common/Sidebar';
import Input from '../../common/Input.js'
import Button from '../../common/Button.js'
import { useState, useEffect,useContext } from 'react'
import { BaseUrl } from '../../env/baseurl';
import { useNavigate } from "react-router-dom";
import VisibilityOffOutlinedIcon from '@mui/icons-material/VisibilityOffOutlined';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import LoginLogo from "../../assets/images/loginLogo.png";
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import VisibilityIcon from '@mui/icons-material/Visibility';
import AuthContext from "../../.././context/AuthProvider.js"
import ErrorIcon from '@mui/icons-material/Error';

function LoginPage() {

  const [email, setEmail] = useState("");
  const [rawPassword, setRawPassword] = useState("");
  const [error, setError] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false)
  const navigate = useNavigate();


  const { setNavbarProfileImage } = useContext(AuthContext);

  const redirect = () => {
    //Role based redirection
    const decipher = (salt) => {
      const textToChars = text => text.split('').map(c => c.charCodeAt(0));
      const applySaltToChar = code => textToChars(salt).reduce((a, b) => a ^ b, code);
      return encoded => encoded.match(/.{1,2}/g)
        .map(hex => parseInt(hex, 16))
        .map(applySaltToChar)
        .map(charCode => String.fromCharCode(charCode))
        .join('');
    }
    function getItemFromLocal(localData) {
      const encryptedData = localStorage.getItem(localData);
      if (encryptedData) {
        const decryptedData = decipher('mySecretSalt')(encryptedData);
        return JSON.parse(decryptedData);
      }
      return null;
    }
    let userData = getItemFromLocal("user_crypt");

    const { Role } = userData;
    

    if (Role === 1) {
      navigate('/dashboard');
    } else if (Role === 2) {
      navigate('/dashboardPM');
    } else if (Role === 3) {
      navigate('/dashboardpl');
    } else if (Role === 4) {
      navigate('/dashboardEM');
    } else {
   
    }

  }


  //Password Encryption
  const cipher = salt => {
    const textToChars = text => text.split('').map(c => c.charCodeAt(0));
    const byteHex = n => ("0" + Number(n).toString(16)).substr(-2);
    const applySaltToChar = code => textToChars(salt).reduce((a, b) => a ^ b, code);
    return text => text.split('')
      .map(textToChars)
      .map(applySaltToChar)
      .map(byteHex)
      .join('');
  }
  const mycipher = cipher('mySecretSalt')
 

  //LocalStorage function
  function storeInLocal(data_arr) {
    const myJSON = (JSON.stringify(data_arr));
    // localStorage.setItem("user_local", myJSON);
    localStorage.setItem("user_crypt", mycipher(myJSON));
  }

  //Getting user input with props
  const getInput = (e) => {
    e.preventDefault()
    return e.target.value;
  }
  //eye icon code
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const loginValidation = (e) => {
    e.preventDefault()
    const mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    if (email === "") {
      setError("Enter your email address");
    } else if (!email.match(mailformat)) {
      setError("Invalid Email");
    } else if (password === "") {
      setError("Enter your password");
    } else {
      setError("");

      //API Block: POST Request
      let userData = {
        Email: email,
        Password: password
      }

     
      let url = BaseUrl + "api/login"
      fetch(url, {
        method: "post",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(userData),
      })
        .then(response => response.json())
        .then(data => {
        
          if (data.status === 500) {
            alert("Internal Server Error");
          } else if (data.status === 300) {
            setError("Invalid credentials");
          } else if (data.status === 200) {
            if (data.data[0].isDelete !== 0) {
              setError("User was deleted");
            } else if (data.data[0].isActive !== 1) {
              setError("User is inactive");
            } else {
              const { Role, EmployeeName, EmployeeID, Email, JoiningDate,ProfileImage } = data.data[0];
              setNavbarProfileImage(ProfileImage)
              const userDataLocal = {
                Role: Role,
                EmployeeID: EmployeeID,
                EmployeeName: EmployeeName,
                Email: Email,
                JoiningDate: JoiningDate,
                ProfileImage: ProfileImage,
              }

              storeInLocal(userDataLocal)
          

              redirect();

            }
            // (data.data[0].isActive==1)? navigate('/admin'): setError("User is inactive");
          }
        })

    }
  }

  return (
    <>
      <div className='login-body'>
       
        <div className="container">
        <img src={LoginLogo} className="login-page-image"/>
          <form>
            <div>
              <h3>Login </h3>
              <p className='Login-page-heading-two'>Access to our dashboard</p>
            </div>
            <div className='Login-page-email-heading-div'>
              <p className='Login-page-email-heading'>Email Address</p>
              <Input type="email" id="email" name="username" maxLength='35' classfield="inputField" onChange={(e) => setEmail(getInput(e))} />
            </div>
            <div className='Login-page-email-heading-div'>
              <p className='Login-page-password-heading'>Password</p>
              <Input type={showPassword ? "text" : "password"} value={rawPassword} id="password" name="password" maxLength='30' classfield="inputField"
                onChange={(e) => {
                  setPassword(mycipher(getInput(e)));
                  setRawPassword(getInput(e))
                }
                } />
              <i className="eye-icon" onClick={togglePasswordVisibility}>
                {showPassword ? <VisibilityIcon sx={{ color: "gray" }} /> : <VisibilityOffIcon sx={{ color: "gray" }} />}
              </i>
            </div>
            <div className="error">
              <span className="spanEnd" id="error">
              {error!=""? <ErrorIcon sx={{ fontSize: "18px" , position: "absolute",marginLeft:"-25px" }}/> :""}{error}
                </span>
            </div>
            <div>
              <Button type="button" Title="Login" onClick={loginValidation} classfield={"submitButton"} />
            </div>
          </form>
        </div>
      </div>
    </>

  );
}

export default LoginPage;