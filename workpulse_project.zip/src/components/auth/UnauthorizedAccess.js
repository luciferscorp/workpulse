import React from 'react'
import { useNavigate } from 'react-router-dom'
import ErrorImage from "../assets/images/unauthorized.png";
import Button from '../common/Button';
import "../assets/css/UnauthorizedAccess.css";

function UnauthorizedAccess() {

 const navigate = useNavigate();

  function GoLoginPage() {

  navigate('/login');
}

  return (
    <div className='Error-Entire-container'>
      <div className='Error-message'>
        <h1>  Unauthorized Access </h1>
        </div>
        <div className='Error-img'><img src={ErrorImage}/></div>

      <div className='Error-Page-btn'><Button
              type="button"
              Title="Go To Login"
              classfield={"greenSubmitButton"}
              onClick={GoLoginPage}
            /></div>
    </div>
  )
}

export default UnauthorizedAccess