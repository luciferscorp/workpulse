import React, { useState, useEffect } from "react";
import "../assets/css/AddEmployee.css";

import Input from "./Input.js";
import Button from "./Button.js";
import DropDown from "./DropDown";
import { BaseUrl } from "../env/baseurl";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import ErrorIcon from '@mui/icons-material/Error';

function AddEmployee(props) {
  const [userName, setUserName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [re_Password, setRe_Password] = useState("");
  const [role, setRole] = useState(0);
  const [date, setDate] = useState("");
  const [teamleaderID, setTeamleaderID] = useState("");
  const [LeadersData, setLeadersData] = useState([]);
  const [error, setError] = useState("");
  const [EmailVerify, setEmailVerify] = useState([]);
  const [count, setcount] = useState(0);
  const [showPassword, setShowPassword] = useState(false);
  const [showConformPassword, setshowConformPassword] = useState(false);
  const [EmployeeIDStatus, setEmployeeIDStatus] = useState([]);
  const [EmployeeDATA, setEmployeeDATA] = useState([]);

  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = String(currentDate.getMonth() + 1).padStart(2, "0");
  const day = String(currentDate.getDate()).padStart(2, "0");
  const hours = String(currentDate.getHours()).padStart(2, "0");
  const minutes = String(currentDate.getMinutes()).padStart(2, "0");
  const seconds = String(currentDate.getSeconds()).padStart(2, "0");

  const setFormatDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

  function validatePassword(password) {
    //Password length should be at least 8 characters
    if (password.length < 8) {
      return "Password must be at least 8 characters long";
    }
    //Password should contain at least one uppercase letter
    if (!/[A-Z]/.test(password)) {
      return "Password must contain at least one uppercase letter";
    }
    //Password should contain at least one lowercase letter
    if (!/[a-z]/.test(password)) {
      return "Password must contain at least one lowercase letter";
    }
    //Password should contain at least one digit
    if (!/\d/.test(password)) {
      return "Password must contain at least one digit";
    }
    //Password should contain at least one special character
    if (!/[^a-zA-Z0-9]/.test(password)) {
      return "Password must contain at least one special character";
    }
    //Password is valid
    return true;
    }
  let EmployeeName = EmployeeDATA===null || EmployeeDATA===undefined ? [] : EmployeeDATA.map((items) => items.EmployeeName);
  let EmployeeID = EmployeeDATA===null || EmployeeDATA===undefined ? [] : EmployeeDATA.map((items) => items.EmployeeID);

  let projectLeaders = LeadersData===null || LeadersData===undefined ? [] : LeadersData.map((items) => items.EmployeeName);
  let projectLeaderIDS = LeadersData===null || LeadersData===undefined ? [] :LeadersData.map((items) => items.EmployeeID);

  //eye icon code
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };
  const toggleConformPasswordVisibility = () => {
    setshowConformPassword(!showConformPassword);
  };

  const EmployeeValidation = (e) => {
    e.preventDefault();

    const cipher = (salt) => {
      const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
      const byteHex = (n) => ("0" + Number(n).toString(16)).substr(-2);
      const applySaltToChar = (code) =>
        textToChars(salt).reduce((a, b) => a ^ b, code);
      return (text) =>
        text
          .split("")
          .map(textToChars)
          .map(applySaltToChar)
          .map(byteHex)
          .join("");
    };
    const mycipher = cipher("mySecretSalt");
    const mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (userName === "") {
      setError("Enter your username");
    } else if (!isNaN(userName)) {
      setError("Name should not be with numbers");
    } else if (email === "") {
      setError("Enter your email address");
    } else if (!email.match(mailformat)) {
      setError("Please enter the valid email");
    } else if (EmailVerify.includes(email)) {
      setError("Already exist email");
    } else if (password === "") {
      setError("Enter you password");
    } else if (validatePassword(password) != true) {
      setError(validatePassword(password));
    } else if (re_Password === "") {
      setError("Re-enter you password");
    } else if (password != re_Password) {
      setError("Password does't match");
    } else if (role == "") {
      setError("Select a role");
    } else if (role == 4 && teamleaderID == "") {
      setError("Select a Project Leader");
    } else if (date == "") {
      setError("Pick a date");
    } else {
      setError("");
      const userData = {
        EmployeeName: userName,
        Email: email,
        Password: mycipher(password),
        Role: role,
        JoiningDate: date,
        CreatedOn: setFormatDateTime,
        CreatedBy: "Admin",
        TeamLeader:projectLeaderIDS[teamleaderID],
      };

      let url = BaseUrl + "api/addemployee";
      fetch(url, {
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(userData),
      })
        .then((response) => response.json())
      props.callback(new Date());

      const newUserData = {
        EmployeeName: userName,
        Email: email,
        Password: password,
        Role: role,
      };

      async function fetchNodemailer() {
        try {
          const response = await fetch(BaseUrl + "api/user/sendmails", {
            method: "POST",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
              "Content-Type": "application/json",
            },
            redirect: "follow",
            referrerPolicy: "no-referrer",
            body: JSON.stringify(newUserData),
          });
          const { status, msg } = await response.json();
        } catch (error) {
          console.error("error", error);
        }
      }

      async function FetchEmployeeID() {
        if(role===4){
        try {
          const EmployeeIDDATA = await {EmployeeName : userName}; 
          const response = await fetch("/FetchEmployeeID", {
            method: "POST",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
              "Content-Type": "application/json",
            },
            redirect: "follow",
            referrerPolicy: "no-referrer",
            body: JSON.stringify(EmployeeIDDATA),
          });
          const { data } = await response.json();
          NotifyEmployeeCreated(data[0].EmployeeID,projectLeaders[teamleaderID]);
          NotifyLeaderAssigned(projectLeaderIDS[teamleaderID],projectLeaders[teamleaderID],userName);
        } catch (error) {
          console.error("error", error);
        }
      }
      }

      async function NotifyEmployeeCreated(EmployeeIDStatus,teamleaderID) {
        try {
          const EmployeeDATA = await {
            UserID : EmployeeIDStatus,
            ProjectLeaderName : teamleaderID,
            CreatedOn : setFormatDateTime,
          }; 
          const response = await fetch("/NotifyEmployeeCreated", {
            method: "POST",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
              "Content-Type": "application/json",
            },
            redirect: "follow",
            referrerPolicy: "no-referrer",
            body: JSON.stringify(EmployeeDATA),
          });
          const { status, msg } = await response.json();
        } catch (error) {
          console.error("error", error);
        }
      }
      async function NotifyLeaderAssigned(teamleaderID,teamleaderNAME,userName) {
        try {
          const EmployeeDATA = await {
            UserID : teamleaderID,
            ProjectLeaderName : teamleaderNAME,
            EmployeeName : userName,
            CreatedOn : setFormatDateTime,
          }; 
          const response = await fetch("/NotifyLeaderAssigned", {
            method: "POST",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
              "Content-Type": "application/json",
            },
            redirect: "follow",
            referrerPolicy: "no-referrer",
            body: JSON.stringify(EmployeeDATA),
          });
          const { status, msg } = await response.json();
        } catch (error) {
          console.error("error", error);
        }
      }

      FetchEmployeeID();
      fetchNodemailer();
      props.function();
      props.close();
    }
  };

  async function GetEmployeeData() {
    try {
      const response = await fetch(BaseUrl + "getallusers", {
        method: "GET",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
      });
      const { data } = await response.json();
      setEmployeeDATA(data===null || data===undefined ? [] : data);
      const emaildata = data.map((value) => value.Email);
      setEmailVerify(emaildata);
    } catch (error) {
      console.error("error", error);
    }
  }

   async function fetchDataLeadersName() {
    try {

        const response = await fetch(BaseUrl + "api/getallLeadersNamesAddMembersDropdown", {
            method: "GET",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
                "Content-Type": "application/json",
            },
            redirect: "follow",
            referrerPolicy: "no-referrer",
        });

        const { data } = await response.json();
        setLeadersData(data);
    }
    catch (error) { console.error("error", error); }
}
  useEffect(() => {
    GetEmployeeData();
    fetchDataLeadersName();
  }, []);

  return (
    <div className="empolyee-regcontainer">
      <div>
        <h3 className="empolyee-reg-title">Add Member</h3>
        <buttom className="popup-close-button" onClick={() => props.function()}>
          &times;
        </buttom>
      </div>

      <div className="divison">
        <Input
          type="text"
          id="userName"
          placeholder="Member Name"
          maxLength="25"
          classfield="employee-inputField"
          onChange={(e) => setUserName(e.target.value)}
        />

        <Input
          type="email"
          id="email"
          placeholder="Email"
          maxLength="35"
          classfield="email-inputField"
          onChange={(e) => setEmail(e.target.value)}
        />

        <div>
          <Input
            type={showPassword ? "text" : "password"}
            id="password"
            placeholder="Password"
            maxLength="30"
            classfield="pass-inputField"
            onChange={(e) => setPassword(e.target.value)}
          />
          <i
            className="EmployeePage-eye-icon"
            onClick={togglePasswordVisibility}
          >
            {showPassword ? (
              <VisibilityIcon sx={{ color: "gray", fontSize: "21px" }} />
            ) : (
              <VisibilityOffIcon sx={{ color: "gray", fontSize: "21px" }} />
            )}
          </i>
        </div>
        <div>
          <Input
            type={showConformPassword ? "text" : "password"}
            id="re_Password"
            placeholder="Confirm Password"
            maxLength="30"
            classfield="cnf-pass-inputField"
            onChange={(e) => setRe_Password(e.target.value)}
          />
          <i
            className="EmployeePage-eye-icon"
            onClick={toggleConformPasswordVisibility}
          >
            {showConformPassword ? (
              <VisibilityIcon sx={{ color: "gray", fontSize: "21px" }} />
            ) : (
              <VisibilityOffIcon sx={{ color: "gray", fontSize: "21px" }} />
            )}
          </i>
        </div>
      </div>

      <div>
        <DropDown
          id="dropdown"
          Title="Select Role"
          classfield="register-dropdown"
          values={["Project Manager", "Project Leader", "Employee"]}
          onChange={(e) => setRole(2 + +e.target.value)}
        />
      </div>
      <div>
        <DropDown
          id="dropdown"
          Title="Select Leader"
          classfield={`${role === 4 ? "register-dropdown-notHide" : "register-dropdown-hide"}`} 
          values={projectLeaders}
           onChange={(e) => setTeamleaderID(e.target.value)}
        />
      </div>
      <div>
        <Input
          type="date"
          id="join_date"
          placeholder="Joining Date"
          classfield="registerdateField"
          onChange={(e) => setDate(e.target.value)}
          maxDate={new Date().toJSON().slice(0, 10)}
          required
        />
      </div>
      <span className="spanEnd" id="error">
       {error!=""? <ErrorIcon sx={{ fontSize: "18px" , position: "absolute",marginLeft:"-25px" }}/> :""} {error}
      </span>
      <div>
        <Button
          type="button"
          Title="Submit"
          onClick={EmployeeValidation}
          classfield={"blue-submit-button"}
        />
      </div>
    </div>
  );
}

export default AddEmployee;