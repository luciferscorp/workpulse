import React, { useState, useEffect } from 'react';
import '../assets/css/ProjectsPagination.css';
import { BaseUrl } from '../env/baseurl';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import DoneIcon from '@mui/icons-material/Done';
import TextField from '@mui/material/TextField';
import Button from "./Button.js";
import Input from "./Input.js";
import EditStatusPopup from './EditStatusPopup';

import tapimg from "../assets/images/tap.png"

import AssignLeader from './AssignLeader';
import { handleBreakpoints } from '@mui/system';
import TouchAppIcon from '@mui/icons-material/TouchApp';
import TouchAppTwoToneIcon from '@mui/icons-material/TouchAppTwoTone';
import TouchAppOutlinedIcon from '@mui/icons-material/TouchAppOutlined';


const ProjectManagerPagination = (props) => {


    const [currentPage, setCurrentPage] = useState(1);
    const [data, setdata] = useState([]);
    const [records, setrecords] = useState([]);
    const [totalPage, settotalPage] = useState();
    const [numbers, setnumbers] = useState([]);

    const recordPerPage = 5;
    const lastIndex = currentPage * recordPerPage;
    const firstIndex = lastIndex - recordPerPage;
    const [activeProjectId, setactiveProjectId] = useState(null);
    const [activeProjectName, setactiveProjectName] = useState("");
    const [activeProjectDescription, setactiveProjectDescription] = useState("");
    const [hide, setHide] = useState(false);
    const [hideEdit, setHideEdit] = useState(new Set());
    /// set() consist of add , delete, has 
    const [counter, setcounter] = useState(0);
    const [newpage, setnewpage] = useState(0);
    const [isAssign, setisAssign] = useState(false);

    const [assignDetails, setassignDetails] = useState(null);

    const [fetchStatus, setfetchStatus] = useState(null);

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isSaved, setisSaved] = useState(false)
    const [payload, setpayload] = useState('initialState');
    const [count, setcount] = useState(0);
    const [incrementCount, setIncrementCount] = useState(0);
    
    const handleIncrementCount = () => {
        if (count > 0) {
         
          setcount(0);
        }
      
        setIncrementCount(incrementCount + 1);
    
      };

    const callback = payload => {
        
        setfetchStatus(payload)
    }

    function prePage() {
        if (currentPage !== 1) {
            setCurrentPage(currentPage - 1);
            setnewpage(newpage - recordPerPage);
        }
    }
    function changePage(newPage) {
        if (newPage !== currentPage) {
            setCurrentPage(newPage);
            setnewpage(0);
            if (newPage > numbers[0]) {
                setnewpage(newpage + recordPerPage);
            }
            if (newPage < numbers[0]) {
                setnewpage(newpage - recordPerPage);
            }
        }
    }
    function nextPage() {
        if (currentPage !== totalPage) {
            setCurrentPage(currentPage + 1);
            setnewpage(newpage + recordPerPage);
        }
    }

    //api get function 
    async function fetchData() {
        try {
            let url = BaseUrl + "api/getallprojects/unassigned"
            const response = await fetch(url, {
                method: "GET",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
            });
            const { data } = await response.json();
            setdata(data)
            setrecords(data.slice(firstIndex, lastIndex))
            settotalPage(Math.ceil(data.length / recordPerPage))
        }
        catch (error) { console.error("error", error); }
    }




    useEffect(() => {
        fetchData();

        setnumbers(Array.from({ length: totalPage }, (_, index) => index + 1));
    }, [currentPage, totalPage]);


    useEffect(() => {
    
        setTimeout(() => {
            fetchData();
        }, 400);
    }, [fetchStatus]);



    //api put function 
    async function updateProjectFunction(projectUpdateParam) {
        try {
            const updateProjectData =
            {
                ProjectName: activeProjectName,
                Description: activeProjectDescription,
                ProjectID: projectUpdateParam
            }
            const response = await fetch(BaseUrl + "updateProjectData", {
                method: "put",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(updateProjectData),
            })
            const data = await response.json();
            // if (counter > 0) {
            //     refreshPage()
            // }
        }
        catch (error) { console.error("Error", error); }
    }

    //api delete function 
    async function deleteProjectRecord(projectDeleteParam) {
        try {
            const deleteProjectData = { id: projectDeleteParam };
            const response = await fetch(BaseUrl + 'deleteProjectData', {
                method: "put",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(deleteProjectData),
            });
            const data = await response.json();
           
            if (counter >= 0) {
                refreshPage()
            }
        } catch (error) {
            console.error("error", error);
        }
    }

    const handleClick = () => {
        setisAssign(false)
    }
    const handleDone = () =>{
        setisAssign(false);
        setisSaved(true);
        handleIncrementCount();
    }

    function refreshPage() { window.location.reload(); }

    return (
        <>
         <div>
                {isSaved && (<EditStatusPopup message={"successfully Assigned!"} timeout={2000}  handleIncrementCount={handleIncrementCount}  />)}
                </div>
           {data===undefined || data.length==0 ?<div className="prj-bodycontainer"><div className='prj-tablecontainer'><h2>No leader have been created yet</h2></div></div> : <div className="prj-bodycontainer">
                <div className='prj-tablecontainer'>
                    <table className="prj-tablecontent">
                        {/* <h4 className='ProjectManagerPagination-heading' >Project Leaders Details</h4> */}
                        <thead>
                            <th className='prj-tablehead'>S.No</th>
                            <th className='prj-tablehead'>Project Name</th>
                            <th className='prj-tablehead'>Description</th>
                            <th className='prj-tablehead'>Company Name</th>
                            <th className='prj-tablehead'>Project Leader</th>
                            <th className='prj-tablehead'>Start Date</th>
                            <th className='prj-tablehead'>End Date</th>
                            <th className='prj-tablehead'>Assign</th>
                        </thead>
                        <tbody className='prj-tablebody'>
                            {records.map((ArrayData, i) => (
                                <tr className='prj-tablerow' key={i}>

                                    {/* project name  */}
                                    <td className='prj-tabledata'>{i + 1 + newpage}</td>
                                    <td className='prj-tabledata'>
                                        {ArrayData.ProjectName}
                                    </td>
                                    <td className='prj-tabledata prj-tabledata-desc'>{ArrayData.Description}</td>
                                    <td className='prj-tabledata'>{ArrayData.CompanyName}</td>
                                    <td className='prj-tabledata'>{ArrayData.ProjectLeader == null ? "-" : ArrayData.EmployeeName}</td>
                                    <td className='prj-tabledata'>{ArrayData.StartDate == null ? "-" : ArrayData.StartDate}</td>
                                    <td className='prj-tabledata'>{ArrayData.EndDate == null ? "-" : ArrayData.EndDate}</td>
                                    <td className='prj-tabledata'>
                                        {/* <img src={tapimg} className="tap-icon-png" onClick={
                                            () => {
                                                setisAssign(true);
                                                setcount(count + 1);
                                                setisSaved(false);
                                                setassignDetails({
                                                    ProjectName: ArrayData.ProjectName,
                                                    ProjectID: ArrayData.ProjectID,
                                                    CompanyName: ArrayData.CompanyName,
                                                    ProjectDescription : ArrayData.Description,
                                                })
                                            }
                                        }
                                        /> */}
                                         <TouchAppOutlinedIcon  sx={{ color: '#5f4d4d',fontSize: '35px',cursor: 'pointer','&:hover': {color: '#2d2828', }}} onClick={
                                            () => {
                                                setisAssign(true);
                                                setcount(count + 1);
                                                setisSaved(false);
                                                setassignDetails({
                                                    ProjectName: ArrayData.ProjectName,
                                                    ProjectID: ArrayData.ProjectID,
                                                    CompanyName: ArrayData.CompanyName,
                                                    ProjectDescription : ArrayData.Description,
                                                })
                                            }
                                        }
                                         
                                         />

                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                {isAssign && <AssignLeader handleclick_close={handleClick} handleclick_done={handleDone} assign_details={assignDetails} callback={callback} />}
            </div>}

            {data===undefined || data.length==0 ? "" : <div className='prj-navbar'>
                <ul className='prj-pagination'>
                    <li className='prj-page-item'>
                        <a href='#' className='prj-page-link' onClick={prePage}>Prev</a>
                    </li>
                    {
                        numbers.map((n, i) => (
                            <li className={`prj-page-item ${currentPage === n ? 'active' : ''}`} key={i}>
                                <a href='#' className='prj-page-link' onClick={() => changePage(n)}>{n}</a>
                            </li>
                        ))
                    }
                    <li className='prj-page-item'>
                        <a href='#' className='prj-page-link' onClick={nextPage}>Next</a>
                    </li>
                </ul>
            </div>}
        </>
    )



}

export default ProjectManagerPagination;