import { React, useState, useEffect, useContext, useRef } from "react";
import "./../assets/css/button.css";

const LimitedText = ({ text, limit }) => {
    const [showAll, setShowAll] = useState(false);
  
    const showMore = () => setShowAll(true);
    const showLess = () => setShowAll(false);
    if (text.length <= limit) {
      return <div>{text}</div>;
    }
  
    if (showAll) {
      return <div className="Limited-Text-showless">{text}<button  className="Limited-Text-btn" onClick={showLess}>Read less</button></div>;
    }
  
    const toShow = text.substring(0, limit) + "...";
    return <div className="Limited-Text-showless">{toShow}<button  className="Limited-Text-btn" onClick={showMore}>Read more</button></div>;
  }
  export default LimitedText;