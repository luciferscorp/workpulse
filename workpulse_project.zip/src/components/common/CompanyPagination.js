import React, { useState, useEffect } from 'react';
import { Icon, IconButton } from '@mui/material';

import '../assets/css/CompanyPagination.css';
import { BaseUrl } from '../env/baseurl';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import DoneIcon from '@mui/icons-material/Done';
import ConfirmDelete from './ConfirmDelete';
import EditDetails from './EditCompanyDetails';
import EditStatusPopup from './EditStatusPopup';


const CompanyPagination = (props) => {

    const [currentPage, setCurrentPage] = useState(1);
    const [data, setdata] = useState([]);
    const [records, setrecords] = useState([]);
    const [totalPage, settotalPage] = useState();
    const [numbers, setnumbers] = useState([]);
    const recordPerPage = 5;
    const lastIndex = currentPage * recordPerPage;
    const firstIndex = lastIndex - recordPerPage;
    const [activeEmployeeId, setActiveEmployeeId] = useState(null);
    const [activeCompanyIdStatus, setactiveCompanyIdStatus] = useState(true);
    const [activeCompanyID, setactiveCompanyID] = useState(undefined);
    const [activeCompanyName, setactiveCompanyName] = useState("");
    const [activeIsActive, setActiveIsActive] = useState(null);
    const [hide, setHide] = useState(false);
    const [hideDropDown, sethideDropDown] = useState(false);
    const [hideEdit, setHideEdit] = useState(new Set());
    /// set() consist of add , delete, has 
    const [counter, setcounter] = useState(0);
    const [isActive, setisActive] = useState(false);
    const [tobeDeleted, settobeDeleted] = useState("");
    const [CompanyIdCompare, setCompanyIdCompare] = useState(0);
    const [WhileClick, setWhileClick] = useState(false);
    const [newpage, setnewpage] = useState(0);


    const [dataIn, setdataIn] = useState(undefined);
    const [activeEdit, setactiveEdit] = useState(false);
    const [editedDetails, setEditedDetails] = useState();
    const [fetchStatus, setfetchStatus] = useState("");
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isSaved, setisSaved] = useState(false)
    const [count, setcount] = useState(0);
    const [payload, setpayload] = useState('initialState');
    const [incrementCount, setIncrementCount] = useState(0);

    const callback = payload => {
      
        setfetchStatus(payload)
    }
  
    
      const handleIncrementCount = () => {
        if (count > 0) {
          
          setcount(0);
        }
      
        setIncrementCount(incrementCount + 1);
    
      };


    function prePage() {
        if (currentPage !== 1) {
            setCurrentPage(currentPage - 1);
            setnewpage(newpage - recordPerPage);
        }
    }
    function changePage(newPage) {
        if (newPage !== currentPage) {
            setCurrentPage(newPage);
            setnewpage(0);
            if (newPage > numbers[0]) {
                setnewpage(newpage + recordPerPage);
            }
            if (newPage < numbers[0]) {
                setnewpage(newpage - recordPerPage);
            }
        }
    }
    function nextPage() {
        if (currentPage !== totalPage) {
            setCurrentPage(currentPage + 1);
            setnewpage(newpage + recordPerPage);
        }
    }

    //api get function 
    async function fetchData() {
        try {
            const response = await fetch(BaseUrl + "getallcompanies", {
                method: "GET",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
            });

            const { data } = await response.json();
            setdata(data)
            setrecords(data.slice(firstIndex, lastIndex))
            settotalPage(Math.ceil(data.length / recordPerPage))

            //     const respond = await response.json().then(result => {
            //     setdata(result.data)
            //     setrecords(result.data.slice(firstIndex, lastIndex))
            //     settotalPage(Math.ceil(result.data.length / recordPerPage))
            // // Assuming totalPage is a positive integer
            //     setnumbers(Array.from({ length: totalPage }, (_, index) => index + 1));
            // });


        }
        catch (error) { console.error("error", error); }
    }

    useEffect(() => {
        fetchData();
        setnumbers(Array.from({ length: totalPage }, (_, index) => index + 1));
    }, [currentPage, totalPage,fetchStatus]);

    useEffect(() => {
     
        setTimeout(() => {
            fetchData();
        }, 400);
    }, [props.doFetch,fetchStatus]);



    //api put function 
    async function updateEmpFunction(cmpid) {
        try {
            const updateUserData = {
                isactivate: activeIsActive,
                CompanyID: cmpid,
                CompanyName: activeCompanyName,
            }
            const response = await fetch(BaseUrl + "updateCompanyUsers", {
                method: "put",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(updateUserData),
            })
            const data = await response.json();
     


        }
        catch (error) { console.error("Error---", error); }
    }

    //api delete function 
    async function deleterecord(id) {
        try {
            const deleteData = { id: id };
            const response = await fetch(BaseUrl + 'deletecomapanyrecord', {
                method: "put",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(deleteData),
            });

            const data = await response.json();
       

        } catch (error) {
            console.error("error", error);
        }

    }

    function handleclick() {
        setisActive(true)
    }

    function handleclick_no() {
        setisActive(false)
    }

    function handleclick_yes() {
        deleterecord(tobeDeleted)
        fetchData()
        setisActive(false)
    }
    function handleclick_doneEdit() {
        setActiveEmployeeId(!activeCompanyID);
        fetchData()
        setActiveIsActive(activeIsActive);
        setcounter(counter + 1);
        setactiveCompanyIdStatus(!activeCompanyID)
        sethideDropDown(!hideDropDown)
        setHide(!hide)
        setCompanyIdCompare(false)
        setWhileClick(false)
        setactiveEdit(false)
        setisSaved(true);
        handleIncrementCount();

    }

    function handleclick_close() {
        setActiveEmployeeId(!activeCompanyID);
        fetchData()
        setActiveIsActive(activeIsActive);
        setcounter(counter + 1);
        setactiveCompanyIdStatus(!activeCompanyID)
        sethideDropDown(!hideDropDown)
        setHide(!hide)
        setCompanyIdCompare(false)
        setWhileClick(false)
        setactiveEdit(false)

    }



    return (
        <>
        <div> 
            {isSaved && (<EditStatusPopup message={"successfully Edited!"} timeout={2000}  handleIncrementCount={handleIncrementCount}  />)}
            </div>
            {data === undefined || data.length == 0 ? <div className="cmp-bodycontainer"><div className='cmp-tablecontainer'><h2>No company have been created yet</h2></div></div> : <div className="cmp-bodycontainer">
                <div className='cmp-tablecontainer'>
                    <table className="cmp-tablecontent">
                        {/* <h4 className='CompanyPagination-heading' >Company Details</h4> */}
                        <thead>
                            <th className='cmp-tablehead'>S.No</th>
                            <th className='cmp-tablehead'>Company Name</th>
                            <th className='cmp-tablehead'>Created By</th>
                            <th className='cmp-tablehead'>Created On</th>
                            <th className='cmp-tablehead'>Status</th>
                            <th className='cmp-tablehead'>Action</th>
                        </thead>
                        <tbody className='cmp-tablebody'>
                            {records.map((ArrayData, i) => (
                                <tr className='cmp-tablerow' key={i}>
                                    <td className='cmp-tabledata'>{i + 1 + newpage}</td>
                                    <td className='cmp-tabledata'>
                                        {ArrayData.CompanyName}

                                    </td>
                                    <td className='cmp-tabledata'>{ArrayData.CreatedBy}</td>
                                    <td className='cmp-tabledata'>{ArrayData.CreatedOn.split(" ")[0]}</td>
                                    <td className='cmp-tabledata'>

                                        {ArrayData.isActive === 1 ? <p className='company-activeStatus'>Active</p> : <p className='company-disableStatus'>InActive</p>}

                                    </td>
                                    <td className='cmp-tabledata tabledata-Action '>
                                        {ArrayData.CompanyID !== activeEmployeeId &&
                                            <IconButton disabled={CompanyIdCompare ? true : false} sx={{ color: "#54B4D3", margin: "0 -15px 0 0" }}>

                                                <EditIcon sx={{ cursor: "pointer" }}
                                                    onClick={() => {
                                                        setactiveEdit(true);
                                                        setcount(count + 1);
                                                        setisSaved(false);
                                                        setactiveCompanyName(ArrayData.CompanyName)
                                                        setCompanyIdCompare(ArrayData.CompanyID);
                                                        setactiveCompanyID(ArrayData.CompanyID);
                                                        setWhileClick(true);
                                                        // updateEmpFunction(ArrayData.CompanyID);
                                                        setActiveEmployeeId(ArrayData.CompanyID);
                                                        setActiveIsActive(ArrayData.isActive);
                                                        setHide(!hide)
                                                        sethideDropDown(!hideDropDown)
                                                        setHideEdit(hideEdit.add(ArrayData.CompanyID));
                                                        setcounter(counter + 1);
                                                        setactiveCompanyIdStatus(ArrayData.CompanyID)
                                                        setdataIn([
                                                            {
                                                                CompanyID: ArrayData.CompanyID,
                                                                CompanyName: ArrayData.CompanyName,
                                                                isActive: ArrayData.isActive
                                                            }
                                                        ]
                                                        )

                                                    }} />
                                            </IconButton>}

                                        {hide && ArrayData.CompanyID === activeEmployeeId &&
                                            (<DoneIcon sx={{ cursor: "pointer", marginBottom: "-8px", marginLeft: "6px", marginRight: "-5px", Button: "-5px", color: "#5cb85c" }}
                                                onClick={() => {

                                                    // updateEmpFunction(ArrayData.CompanyID);
                                                    setActiveEmployeeId(!ArrayData.CompanyID);
                                                    fetchData()
                                                    setActiveIsActive(ArrayData.isActive);
                                                    setcounter(counter + 1);
                                                    setactiveCompanyIdStatus(!ArrayData.CompanyID)
                                                    sethideDropDown(!hideDropDown)
                                                    setHide(!hide)
                                                    setCompanyIdCompare(false)
                                                    setWhileClick(false)
                                                    setactiveEdit(false)

                                                }} />)}

                                        {/* <DeleteIcon onClick={() => (deleterecord(ArrayData.CompanyID))} /> */}
                                        {ArrayData.CompanyID &&
                                            <IconButton disabled={WhileClick} sx={{ color: "#DC3545" }}>
                                                <DeleteIcon sx={{ cursor: "pointer", marginLeft: "5px" }} onClick={() => {
                                                    // deleteProjectRecord(ArrayData.ProjectID)
                                                    handleclick();
                                                    settobeDeleted(ArrayData.CompanyID)
                                                }} />
                                            </IconButton>
                                        }

                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                {isActive && <ConfirmDelete content={"company"} clickNo={() => handleclick_no()} clickYes={() => handleclick_yes()} />}
                {activeEdit && <EditDetails dataIn={dataIn} clickClose={() =>  handleclick_close()} clickDone={() => handleclick_doneEdit()}
                    callback={callback}
                />}
                 
            </div>}

            {data === undefined || data.length == 0 ? "" : <div className='cmp-navbar'>
                <ul className='cmp-pagination'>
                    <li className='cmp-page-item'>
                        <a href='#' className='cmp-page-link' onClick={prePage}>Prev</a>
                    </li>
                    {
                        numbers.map((n, i) => (
                            <li className={`cmp-page-item ${currentPage === n ? 'active' : ''}`} key={i}>
                                <a href='#' className='cmp-page-link' onClick={() => changePage(n)}>{n}</a>
                            </li>
                        ))
                    }
                    <li className='cmp-page-item'>
                        <a href='#' className='cmp-page-link' onClick={nextPage}>Next</a>
                    </li>
                </ul>
            </div>}
        </>
    )



}

export default CompanyPagination;