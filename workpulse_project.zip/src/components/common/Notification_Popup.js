import React, { useMemo, useEffect } from 'react';
import {
    RadiusUprightOutlined
} from '@ant-design/icons';
import { Button, Divider, notification, Space } from 'antd';
const Context = React.createContext({
    name: 'Default',
});
const NotifiPopup = (props) => {
    const [api, contextHolder] = notification.useNotification();
    const openNotification = (placement) => {
        api.info({
            message: `Notification ${placement}`,
            description: <Context.Consumer>{({ name }) => `Hello, ${name}!`}</Context.Consumer>,
            placement,
        });
    };
    const contextValue = useMemo(
        () => ({
            name: 'Ant Design',
        }),
        [],
    );

    useEffect(() => {

        if ( props.click !=null ) {
            openNotification('topRight')
        }

    }, [props.click]);



    return (
        <Context.Provider value={contextValue}>
            {contextHolder}
            <Space>
                <Button
                    type="primary"
                    onClick={() => openNotification('topRight')}

                >
                    topRight
                </Button>
            </Space>
        </Context.Provider>
    );
};
export default NotifiPopup;