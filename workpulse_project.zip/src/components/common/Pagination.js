import React, { useState, useEffect } from "react";
import "../assets/css/Pagination.css";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import DoneIcon from "@mui/icons-material/Done";
import Button from "./Button.js";
import Input from "./Input.js";
import { BaseUrl } from "../env/baseurl";
import ConfirmDelete from "./ConfirmDelete";
import { Icon, IconButton } from "@mui/material";
import Switch from "@mui/material/Switch";
import FormControlLabel from "@mui/material/FormControlLabel";

const Pagination = (props) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [data, setdata] = useState([]);
  const [records, setrecords] = useState([]);
  const [totalPage, settotalPage] = useState();
  const [numbers, setnumbers] = useState([]);
  const recordPerPage = 5;
  const lastIndex = currentPage * recordPerPage;
  const firstIndex = lastIndex - recordPerPage;
  const [activeEmployeeId, setActiveEmployeeId] = useState(null);
  const [activeEmployeeIdStatus, setactiveEmployeeIdStatus] = useState(true);
  const [activeIsActive, setActiveIsActive] = useState(null);
  const [hide, setHide] = useState(false);
  const [hideEdit, setHideEdit] = useState(new Set());
  const [hideDropDown, sethideDropDown] = useState(false);
  const [EmployeeIdCompare, setEmployeeIdCompare] = useState(0);
  const [WhileClick, setWhileClick] = useState(false);
  /// set() consist of add , delete, has
  const [counter, setcounter] = useState(0);
  const [isActive, setisActive] = useState(false);
  const [tobeDeleted, settobeDeleted] = useState("");
  //toggle button
  const [switchValue, setSwitchValue] = useState(false);
  const [newpage, setnewpage] = useState(0);

  const handleSwitchChange = () => {
    setSwitchValue((prevValue) => !prevValue);
  };
  function prePage() {
    if (currentPage !== 1) {
      setCurrentPage(currentPage - 1);
      setnewpage(newpage - recordPerPage);
    }
  }
  function changePage(newPage) {
    if (newPage !== currentPage) {
      setCurrentPage(newPage);
      setnewpage(0);
      if (newPage > numbers[0]) {
        setnewpage(newpage + recordPerPage);
      }
      if (newPage < numbers[0]) {
        setnewpage(newpage - recordPerPage);
      }
    }
  }
  function nextPage() {
    if (currentPage !== totalPage) {
      setCurrentPage(currentPage + 1);
      setnewpage(newpage + recordPerPage);
    }
  }

  //api get function
  async function fetchData() {
    try {
      const response = await fetch(BaseUrl + "getallusers", {
        method: "GET",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
      });
      const { data } = await response.json();
      setdata(data);
      setrecords(data.slice(firstIndex, lastIndex));
      settotalPage(Math.ceil(data.length / recordPerPage));
    } catch (error) {
      console.error("error", error);
    }
  }

  useEffect(() => {
    fetchData();
    setnumbers(Array.from({ length: totalPage }, (_, index) => index + 1));
  }, [currentPage, totalPage]);

  useEffect(() => {
   
    setTimeout(() => {
      fetchData();
    }, 400);
  }, [props.doFetch]);

  // let currentDateRaw = new Date()
  // let UpdateOn = currentDateRaw.toISOString().split('T')[0].split("-").reverse().join("/");

  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = String(currentDate.getMonth() + 1).padStart(2, "0");
  const day = String(currentDate.getDate()).padStart(2, "0");
  const hours = String(currentDate.getHours()).padStart(2, "0");
  const minutes = String(currentDate.getMinutes()).padStart(2, "0");
  const seconds = String(currentDate.getSeconds()).padStart(2, "0");

  const setFormatDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

  //api put function
  async function updateEmpFunction(empid) {
    try {
      const updateUserData = {
        isactivate: activeIsActive,
        UpdatedOn: setFormatDateTime,
        EmployeeID: empid,
      };
      const response = await fetch(BaseUrl + "updateEmployeeUsers", {
        method: "put",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(updateUserData),
      });
      const data = await response.json();
     

      // if (counter > 0) {
      //     refreshPage()
      // }
    } catch (error) {
      console.error("Error---", error);
    }
  }

  //api delete function
  async function deleterecord(id) {
    try {
      const deleteData = { id: id };
      const response = await fetch(BaseUrl + "deleterecord", {
        method: "put",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(deleteData),
      });

      const data = await response.json();
     
      // if (counter >= 0) {
      //     refreshPage()
      // }
    } catch (error) {
      console.error("error", error);
    }
  }

  function handleclick() {
    setisActive(true);
  }

  function handleclick_no() {
    setisActive(false);
  }

  function handleclick_yes() {
    deleterecord(tobeDeleted);
    fetchData();
    setisActive(false);
  }

  function refreshPage() {
    window.location.reload();
  }
  //toggle button

  return (
    <>
      {data === undefined || data.length == 0 ? (
        <div className="emp-bodycontainer">
          <div className="emp-tablecontainer">
            <h2>No employees have been created yet</h2>
          </div>
        </div>
      ) : (
        <div className="emp-bodycontainer">
          <div className="emp-tablecontainer">
            <table className="emp-tablecontent">
              {/* <h4 className="pagination-heading">Member Details</h4> */}
              <thead>
                <th className="emp-tablehead">S.No</th>
                <th className="emp-tablehead">Member Name</th>
                <th className="emp-tablehead">Email</th>
                <th className="emp-tablehead">Role Name</th>
                <th className="emp-tablehead">Status</th>
                <th className="emp-tablehead">Joining Date</th>
                <th className="emp-tablehead">Action</th>
              </thead>
              <tbody className="emp-tablebody">
                {records.map((ArrayData, i) => (
                  <tr className="emp-tablerow" key={i}>
                    <td className="emp-tabledata">{i + 1 + newpage}</td>
                    <td className="emp-tabledata">{ArrayData.EmployeeName}</td>
                    <td className="emp-tabledata">{ArrayData.Email}</td>
                    <td className="emp-tabledata">{ArrayData.rolename}</td>
                    <td className="emp-tabledata">
                      {ArrayData.EmployeeID === activeEmployeeIdStatus &&
                      activeIsActive !== hide ? (
                        ""
                      ) : ArrayData.isActive === 1 ? (
                        <p className="employee-activeStatus">Active</p>
                      ) : (
                        <p className="employee-disableStatus">InActive</p>
                      )}

                      {hideDropDown &&
                        ArrayData.EmployeeID === activeEmployeeId && (
                          <select
                            id="activeStatus"
                            name="status"
                            aria-placeholder="Active"
                            active="select"
                            onChange={(e) => {
                              setActiveIsActive(e.target.value);
                            }}
                          >
                            <option value="none" disabled selected hidden>
                              {activeIsActive === 1 ? "Active" : "InActive"}
                            </option>
                            <option
                              className="employee-status-Active"
                              value="1"
                            >
                              Active
                            </option>
                            <option
                              className="employee-status-disable"
                              value="0"
                            >
                              InActive
                            </option>
                          </select>
                        )}
                    </td>
                    <td className="emp-tabledata">{ArrayData.JoiningDate}</td>
                    <td className="emp-tabledata">
                      {ArrayData.EmployeeID !== activeEmployeeId && (
                        <IconButton
                          disabled={EmployeeIdCompare ? true : false}
                          sx={{ color: "#54B4D3", margin: "0 -12px 0" }}
                        >
                          <EditIcon
                            sx={{ cursor: "pointer" }}
                            onClick={() => {
                              setEmployeeIdCompare(ArrayData.EmployeeID);
                              setWhileClick(true);
                              updateEmpFunction(ArrayData.EmployeeID);
                              setActiveEmployeeId(ArrayData.EmployeeID);
                              setActiveIsActive(ArrayData.isActive);
                              setHide(!hide);
                              sethideDropDown(!hideDropDown);
                              setHideEdit(hideEdit.add(ArrayData.EmployeeID));
                              setcounter(counter + 1);
                              setactiveEmployeeIdStatus(ArrayData.EmployeeID);
                            }}
                          />
                        </IconButton>
                      )}

                      {hide && ArrayData.EmployeeID === activeEmployeeId && (
                        <DoneIcon
                          sx={{
                            cursor: "pointer",
                            marginBottom: "-8px",
                            marginLeft: "-3px",
                            marginRight: "-5px",
                            Button: "-5px",
                            color: "#5cb85c",
                          }}
                          onClick={() => {
                            updateEmpFunction(ArrayData.EmployeeID);
                            fetchData();
                            setActiveEmployeeId(!ArrayData.EmployeeID);
                            setActiveIsActive(ArrayData.isActive);
                            setcounter(counter + 1);
                            setactiveEmployeeIdStatus(!ArrayData.EmployeeID);
                            sethideDropDown(!hideDropDown);
                            setHide(!hide);
                            setEmployeeIdCompare(false);
                            setWhileClick(false);
                          }}
                        />
                      )}

                      {/* <DeleteIcon onClick={() => (deleterecord(ArrayData.EmployeeID))} /> */}
                      {ArrayData.EmployeeID && (
                        <IconButton
                          disabled={WhileClick}
                          sx={{ color: "#DC3545" }}
                        >
                          <DeleteIcon
                            sx={{ cursor: "pointer", marginLeft: "5px" }}
                            onClick={() => {
                              // deleteProjectRecord(ArrayData.ProjectID)
                              handleclick();
                              settobeDeleted(ArrayData.EmployeeID);
                            }}
                          />
                        </IconButton>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {isActive && (
            <ConfirmDelete
              content={"employee"}
              clickNo={() => handleclick_no()}
              clickYes={() => handleclick_yes()}
            />
          )}
        </div>
      )}

      {data === undefined || data.length == 0 ? (
        ""
      ) : (
        <div className="emp-navbar">
          <ul className="emp-pagination">
            <li className="emp-page-item">
              <a href="#" className="emp-page-link" onClick={prePage}>
                Prev
              </a>
            </li>
            {numbers.map((n, i) => (
              <li
                className={`emp-page-item ${currentPage === n ? "active" : ""}`}
                key={i}
              >
                <a
                  href="#"
                  className="emp-page-link"
                  onClick={() => changePage(n)}
                >
                  {n}
                </a>
              </li>
            ))}
            <li className="emp-page-item">
              <a href="#" className="emp-page-link" onClick={nextPage}>
                Next
              </a>
            </li>
          </ul>
        </div>
      )}
    </>
  );
};

export default Pagination;
