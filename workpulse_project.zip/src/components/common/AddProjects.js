import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../assets/css/AddProjects.css";
import MultiselectDropdown from "multiselect-react-dropdown";

import Input from "./Input.js";
import Button from "./Button.js";
import { BaseUrl } from "../env/baseurl";
import DropDown from "./DropDown";
import ErrorIcon from '@mui/icons-material/Error';

const decipher = (salt) => {
  const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
  const applySaltToChar = (code) =>
    textToChars(salt).reduce((a, b) => a ^ b, code);
  return (encoded) =>
    encoded
      .match(/.{1,2}/g)
      .map((hex) => parseInt(hex, 16))
      .map(applySaltToChar)
      .map((charCode) => String.fromCharCode(charCode))
      .join("");
};

const myDecipher = decipher("mySecretSalt");

function getItemFromLocal(localData) {
  let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
  return form_data;
}

const currentDate = new Date();
const year = currentDate.getFullYear();
const month = String(currentDate.getMonth() + 1).padStart(2, "0");
const day = String(currentDate.getDate()).padStart(2, "0");
const hours = String(currentDate.getHours()).padStart(2, "0");
const minutes = String(currentDate.getMinutes()).padStart(2, "0");
const seconds = String(currentDate.getSeconds()).padStart(2, "0");

const setFormatDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

function Addproject(props) {
  const [projectName, setProjectName] = useState("");
  const [projectDescription, setProjectDescription] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [companyRecords, setcompanyRecords] = useState([]);
  const [companyID, setCompanyID] = useState("");
  const [error, setError] = useState("");
  const [ProjectNameVerify, setProjectNameVerify] = useState([]);

  let companies = companyRecords.map((items) => items.CompanyName);
  let companyIDs = companyRecords.map((items) => items.CompanyID);
  const employeeOptions = [
    { label: "John Doe", value: "john_doe" },
    { label: "Jane Smith", value: "jane_smith" },
    // Add more employees as needed
  ];

  //To fetch Company Details from database

  let url = BaseUrl + "api/getcompanies";
  useEffect(() => {
    async function fetchCompanyData() {
      try {
        const response = await fetch(url, {
          method: "GET",
          mode: "cors",
          cache: "no-cache",
          credentials: "same-origin",
          headers: {
            "Content-Type": "application/json",
          },
          redirect: "follow",
          referrerPolicy: "no-referrer",
        });

        const { data } = await response.json();
        setcompanyRecords(data);
      } catch (error) {
        console.error("error", error);
      }
    }
    fetchCompanyData();
  }, []);

  // let currentDateRaw = new Date()
  // let currentDdate = currentDateRaw.toISOString().split('T')[0].split("-").reverse().join("/");

  // const convertDateString = (dateString) => {
  //     return dateString.split("-").reverse().join("/")
  // }

  const ProjectValidation = (e) => {
    e.preventDefault();

    const firstDate = new Date(startDate.split("/").reverse().join("-"));
    const secondDate = new Date(endDate.split("/").reverse().join("-"));

    const mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    if (projectName === "") {
      setError("Enter your project name");
    } else if (!isNaN(projectName)) {
      setError("Project name should not be with numbers");
    } else if (ProjectNameVerify.includes(projectName.toLowerCase())) {
      setError(" Name already exist ");
    } else if (projectDescription === "") {
      setError("Write Project's Description");
    } else if (companyID == "") {
      setError("Select Company");
    } else {
      setError("");

      const userData = getItemFromLocal("user_crypt") || { EmployeeID: null };

      const { EmployeeID, EmployeeName } = userData;

      const projectData = {
        ProjectName: projectName,
        Description: projectDescription,
        CreatedOn: setFormatDateTime,
        CompanyID: companyIDs[companyID],
        CreatedBy: EmployeeID,
        CreatedByName: EmployeeName,
      };

      


      async function fetchData() {
        try {
          let url2 = BaseUrl + "api/addprojects";
          const response = await fetch(url2, {
            method: "POST",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
              "Content-Type": "application/json",
            },
            redirect: "follow",
            referrerPolicy: "no-referrer",
            body: JSON.stringify(projectData),
          });
          const result = await response.json().then((data) => {

          });
        } catch (err) {
          console.error("API Error: ", err);
        }
      }
      fetchData();
      props.callback(new Date());

      props.function();
      props.close();
    }
  };

  //api get function
  async function GetProjectData() {
    try {
      const response = await fetch(BaseUrl + "getallprojects", {
        method: "GET",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
      });
      const { data } = await response.json();

      const projectdata = data.map((value) => value.ProjectName.toLowerCase());

      setProjectNameVerify(projectdata);
    } catch (error) {
      console.error("error", error);
    }
  }
  useEffect(() => {
    GetProjectData();
  }, []);
  return (
    <div className="project-container">
      <div>
        <h3 className="project-reg-title">Add project</h3>
        <buttom
          className="project-popup-close-button"
          onClick={() => props.function()}
        >
          &times;
        </buttom>
      </div>

      <Input
        type="text"
        id="project_name"
        placeholder="Project Name"
        maxLength="30"
        classfield="project-inputField"
        onChange={(e) => setProjectName(e.target.value)}
      />
      <textarea
        rows="6"
        placeholder="Describe the project here..."
        maxLength={150}
        form="usrform"
        className="project-description"
        onChange={(e) => setProjectDescription(e.target.value)}
      ></textarea>
      {/* <div className='divison'>

                <Input type="date" placeholder="Start Date" classfield="startdate-inputField" onChange={(e) => setStartDate(convertDateString(e.target.value))} required/>
                <Input type="date" placeholder="End Date" classfield="enddate-inputField" onChange={(e) => setEndDate(convertDateString(e.target.value))} required />

            </div> */}

      <div>
        <DropDown
          id="dropdown"
          classfield="project-companies-dropdown"
          Title="Select Company"
          values={companies}
          onChange={(e) => setCompanyID(e.target.value)}
        />
      </div>
     
      <span className="spanEnd" id="error">
      {error!=""? <ErrorIcon sx={{ fontSize: "18px" , position: "absolute",marginLeft:"-25px" }}/> :""}{error}
      </span>

      <div>
        <Button
          type="button"
          Title="Add project"
          classfield={"blue-submit-button"}
          onClick={ProjectValidation}
        />
      </div>
    </div>
  );
}

export default Addproject;
