import React, { useState, useEffect } from "react";
import * as FaIcons from "react-icons/fa";
import { Link, useLocation } from "react-router-dom";
import "../assets/css/Sidebar.css";
import { IconContext } from "react-icons";
import ProjectLogo from "../assets/images/Logo.png";
import BlueProjectLogo from "../assets/images/loginLogo.png";

//Sidebar Data
import { SidebarData } from "./SidebarData";

function Sidebar(props) {
  const [sidebar, setSidebar] = useState(true);
  const showSidebar = () => setSidebar(!sidebar || false);
  const location = useLocation();

  const [data, setData] = useState([]);

  const decipher = (salt) => {
    const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
    const applySaltToChar = (code) =>
      textToChars(salt).reduce((a, b) => a ^ b, code);
    return (encoded) =>
      encoded
        .match(/.{1,2}/g)
        .map((hex) => parseInt(hex, 16))
        .map(applySaltToChar)
        .map((charCode) => String.fromCharCode(charCode))
        .join("");
  };
  const myDecipher = decipher("mySecretSalt");

  function getItemFromLocal(localData) {
    let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
    return form_data;
  }

  const userData = getItemFromLocal("user_crypt") || { Role: 4 };

  const { Role } = userData;

  let role = Role;

  useEffect(() => {
    //  setRole({"name":"projectManager"})
    if (role === 1) {
      setData(SidebarData.admin_options);
    } else if (role === 2) {
      setData(SidebarData.projectManager_options);
    } else if (role === 3) {
      setData(SidebarData.projectLeader_options);
    } else if (role === 4) {
      setData(SidebarData.employee_options);
    }

  }, [role]);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    // Initial check
    handleResize();

    // Event listener for window resize
    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  return (
    <>
      <div className="sidebar-body">
        <IconContext.Provider value={{}}>
          <div className="sidebar">
            <Link to="#" className="menubaropen">
              <FaIcons.FaBars onClick={() => showSidebar()} />
            </Link>
            <img src={BlueProjectLogo} className="workpulse-logo-two"/>
    
          </div>
          <nav className={sidebar ? "navmenu active" : "navmenu"}>
            <ul className="navmenuitems">
              <li className="navbartoggle" onClick={() => showSidebar()}>
              {isMobile && (
                <Link to='#' className='menubarclose' onClick={() => showSidebar()}>
                    <FaIcons.FaBars />
                </Link>
            )}
                <p className="sideBar-project-heading">WorkPulse</p>
                <img src={ProjectLogo} className="workpulse-logo" />
              </li>

              {data.map((item, index) => {
                return (
                  <li key={index} className={item.cName}>
                    <Link
                      to={item.path}
                      className={
                        item.path == location.pathname ? "nav-text-active" : ""
                      }
                    >
                      <span className="sidebar-icons-active">{item.icon}</span>
                      <span className="siderbar-title-text">{item.title}</span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>
        </IconContext.Provider>
      </div>
    </>
  );
}

export default Sidebar;
