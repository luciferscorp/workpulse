import React from 'react'
import { useNavigate } from "react-router-dom";

function Loading() {
     const navigate = useNavigate();
    const redirect = () => {
        //Role based redirection
        const decipher = (salt) => {
            const textToChars = text => text.split('').map(c => c.charCodeAt(0));
            const applySaltToChar = code => textToChars(salt).reduce((a, b) => a ^ b, code);
            return encoded => encoded.match(/.{1,2}/g)
                .map(hex => parseInt(hex, 16))
                .map(applySaltToChar)
                .map(charCode => String.fromCharCode(charCode))
                .join('');
        }
        function getItemFromLocal(localData) {
            const encryptedData = localStorage.getItem(localData);
            if (encryptedData) {
                const decryptedData = decipher('mySecretSalt')(encryptedData);
                return JSON.parse(decryptedData);
            }
            return null;
        }
        let userData = getItemFromLocal("user_crypt");

        const { Role } = userData;

        setTimeout(() => {
            if (Role === 1) {
                navigate('/employee');
            } else if (Role === 2) {
                navigate('/projects');
            } else if (Role === 3) {
                navigate('/tasks');
            } else if (Role === 4) {
                navigate('/employeetasks');
            } else {
                redirect();
            }
        }, 700);
    }

    return (
        <div>Loading</div>
    )
}

export default Loading