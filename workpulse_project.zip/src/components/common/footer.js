import React from "react";
import "../assets/css/footer.css";
function Footer() {
  return (
    
    <div className="footer-container">
      {/* <br/><br/><br/> */}
      <footer>
        <p className="footer-content">
          {" "}
          © {new Date().getFullYear()} WorkPulse. All rights reserved.
        </p>
        <p className="footer-content-bottom">
          Terms of Service | Privacy Policy | Contact Us
        </p>
      </footer>
    </div>
  );
}

export default Footer;
// import React from 'react';
// import { MDBFooter } from 'mdb-react-ui-kit';

// export default function footer() {
//   return (
//     <MDBFooter bgColor='light' className='text-center text-lg-left'>
//       <div className='text-center p-3' style={{ backgroundColor: 'rgba(0, 0, 0, 0.2)' }}>
//         © 2024 Copyright:
//         <a className='text-white' href='https://yourwebsite.com/'>
//           Your Website
//         </a>
//       </div>
//     </MDBFooter>
//   );
// }
