import React from 'react'
import "../assets/css/ConfirmDelete.css"
import Button from './Button'


function ConfirmDelete(props) {


    return (
        <div className='cd-model'>
            <div className='cd-container'>
                <p className='cd-text'>{`Are you sure that you want to delete this ${props.content}?`}</p>
                <div className='cd-buttons'>
                    <div className='cd-left-button'>
                        <button className='yes-submit-button' onClick={() => props.clickYes()}> Yes</button>
                    </div>
                    <div className='cd-right-button'>
                        <button className='no-submit-button' onClick={() => props.clickNo()}> No</button></div>
                </div>
            </div>
        </div>
    )
}

export default ConfirmDelete