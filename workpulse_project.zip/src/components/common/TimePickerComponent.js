import * as React from 'react';
import { useState,useContext } from 'react';
import dayjs from 'dayjs';
import AuthContext from '../../context/AuthProvider';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { TimeField } from '@mui/x-date-pickers/TimeField';
import "../assets/css/TimePickerComponent.css"
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import "../assets/css/input.css"


export default function CustomTimeFormat(props) {
  const [getValue, setgetValue] = useState([]);
  const { DefaultValueOnTimer} = useContext(AuthContext);


  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <DemoContainer components={['TimeField', 'TimeField', 'TimeField']}>
        <TimeField

          className='time-picker-field'
          defaultValue={DefaultValueOnTimer}
          format="HH:mm:00"
          onChange={(e) => props.handlechange(e.$d)}
        />
     
      </DemoContainer>
    </LocalizationProvider>
  );
}