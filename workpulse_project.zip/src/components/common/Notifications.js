import { React, useState, useEffect,useContext } from 'react';
import "../assets/css/Notifications.css";
import moment from 'moment';
import CloseIcon from '@mui/icons-material/Close';
import AuthContext from '../../context/AuthProvider';
import Navbar from './Navbar';
import Sidebar from './Sidebar';
import DeleteIcon from '@mui/icons-material/Delete';
import {  IconButton } from '@mui/material';
import Footer from './footer';

const decipher = (salt) => {
  const textToChars = text => text.split('').map(c => c.charCodeAt(0));
  const applySaltToChar = code => textToChars(salt).reduce((a,b) => a ^ b, code);
  return encoded => encoded.match(/.{1,2}/g)
    .map(hex => parseInt(hex, 16))
    .map(applySaltToChar)
    .map(charCode => String.fromCharCode(charCode))
    .join('');
}
  const myDecipher =  decipher('mySecretSalt')

function getItemFromLocal(localData) {
  let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
  return form_data;
  
}

export default function Notifications() {

  let local_data = getItemFromLocal("user_crypt");
  const LoggedID = {EmployeeID: local_data.EmployeeID}
    
  const [createdDate, setCreatedDate] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [data, setdata] = useState([]);
  const [records, setrecords] = useState([]);
  const [totalPage, settotalPage] = useState();
  const [numbers, setnumbers] = useState([]);
  const [Companies, setCompanies] = useState();
  const recordPerPage = 5;
  const lastIndex = currentPage * recordPerPage;
  const firstIndex = lastIndex - recordPerPage;
  const [hide, setHide] = useState(false);
  const [hideEdit, setHideEdit] = useState(new Set());
  /// set() consist of add , delete, has 
  const [counter, setcounter] = useState(0);
  const [newpage, setnewpage] = useState(0);
  const [differenceTime, setDifferenceTime] = useState([]);
  const [InitialTimeObj, setInitialTimeObj] = useState([]);
  const [ReadData, setReadData] = useState([]);
  const [ReadStatus, setReadStatus] = useState([]);
  const { NotifyBadgeReadCount, setNotifyBadgeReadCount, NotificationID, setNotificationID } = useContext(AuthContext);

  setNotificationID(LoggedID.EmployeeID);
  setNotifyBadgeReadCount(ReadData.reduce((sum, value) => sum + (value === 0), 0));

  function prePage() {
    if (currentPage !== 1) {
        setCurrentPage(currentPage - 1);
        setnewpage(newpage-recordPerPage);
    }
}
function changePage(newPage) {
    if (newPage !== currentPage) {
        setCurrentPage(newPage);
        setnewpage(0);
        if (newPage > numbers[0]) {
            setnewpage(newpage + recordPerPage);
        }
        if (newPage < numbers[0]) {
            setnewpage(newpage - recordPerPage);
        }
    }
}
function nextPage() {
    if (currentPage !== totalPage) {
        setCurrentPage(currentPage + 1);
        setnewpage(newpage+recordPerPage);
    }
}


useEffect(() => {
  fetchNotificationData();
}, [data])


  const DeleteNotification = async (NotifyID) => {
    try {
      const DeleteData = { UserID : NotifyID }
      const response = await fetch("/updateIsDelete", {
        method: "put",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(DeleteData),
      })
      const data = await response.json(); 
    } catch (error) {
      console.error("Error", error);
    }
  }

  const fetchNotificationData = async () => {
    try {
      const response = await fetch("/View_all_Notifications", {
        method: "post",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(LoggedID),
      });
      const { data } = await response.json();
      setdata(data===undefined ? [] : data);
      setrecords(data.slice(firstIndex, lastIndex));
      settotalPage(Math.ceil(data.length / recordPerPage));
    } catch (error) {
      console.error("error", error);
    }
  };




  useEffect(() => {

      setnumbers(Array.from({ length: totalPage }, (_, index) => index + 1));

    const FetchNotifyReadDATA = async () => {
      try {
          const NotifyReadDATA = { UserID: NotificationID };
          const response = await fetch("/fetchNotifyReadDATA", {
              method: "post",
              mode: "cors",
              cache: "no-cache",
              credentials: "same-origin",
              headers: {
                  "Content-Type": "application/json",
              },
              redirect: "follow",
              referrerPolicy: "no-referrer",
              body: JSON.stringify(NotifyReadDATA),
          });
          const { data } = await response.json();
          setReadData(data===undefined ? [] : data.map((items) => (items.IsRead)));
  
      } catch (error) {
          console.error("error", error);
      }
  };

    fetchNotificationData();
    FetchNotifyReadDATA();
    DeleteNotification();

  }, [,currentPage, totalPage]);





  return (
    <>
    <div>
    <Sidebar/>
    <Navbar/>
    </div>
      <div>

        <>
            {data === undefined || data.length == 0 ? <div className='notify-data--tablecontainer'><h2>No Notifications have been created yet</h2></div> :
                <div className="notify-data--bodycontainer">
                    <div className='notify-data--tablecontainer'>
                        <table className="notify-data--tablecontent">
          
                            <thead >
                                <th className='notify-data--tablehead notify-data--tablehead-sno'>S.No</th>
                                <th className='notify-data--tablehead notify-data--tablehead-content'>Content</th>
                                <th className='notify-data--tablehead notify-data--tablehead-createdby'>Created By</th>
                                <th className='notify-data--tablehead notify-data--tablehead-createdon'>Created On</th>
                                <th className='notify-data--tablehead notify-data--tablehead-action'>Action</th>
                            </thead>

                            <tbody className='notify-data--tablebody'>
                                {records.map((ArrayData, i) => (
                                    <tr className='notify-data--tablerow' key={i}>

                                        <td className='notify-data--tabledata'>{i + 1 + newpage}</td>
                                        <td className='notify-data--tabledata'>{ArrayData.Content}</td>
                                        <td className='notify-data--tabledata'>{ArrayData.EmployeeName}</td>
                                        <td className='notify-data--tabledata'>{ArrayData.CreatedOn}</td>

                                        <td className='notify-data--tabledata'>
                                            {ArrayData.NotificationID &&
                                                <IconButton sx={{ color: "#DC3545" }}>
                                                    <DeleteIcon sx={{ cursor: "pointer", marginLeft: "5px" }} onClick={() => {
                                                       DeleteNotification(ArrayData.NotificationID);
                                                       fetchNotificationData();
                                                    }} />
                                                </IconButton>}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                   
                </div>}

            {data === undefined || data.length == 0 ? "" :
                <div className='notify-data--navbar'>
                    <ul className='notify-data--pagination'>
                        <li className='notify-data--page-item'>
                            <a href='#' className='notify-data--page-link' onClick={prePage}>Prev</a>
                        </li>
                        {
                            numbers.map((n, i) => (
                                <li className={`notify-data--page-item ${currentPage === n ? 'active' : ''}`} key={i}>
                                    <a href='#' className='notify-data--page-link' onClick={() => changePage(n)}>{n}</a>
                                </li>
                            ))
                        }
                        <li className='notify-data--page-item'>
                            <a href='#' className='notify-data--page-link' onClick={nextPage}>Next</a>
                        </li>
                    </ul>
                </div>}
        </>
    



      </div>
      <div className="report-footer">
          <Footer />
        </div>
    </>
  )
}