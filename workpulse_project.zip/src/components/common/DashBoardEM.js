import React, { useState, useEffect, useContext } from "react";
import "../assets/css/DashboardEM.css";
import { BaseUrl } from "../env/baseurl";

import totalicon from "../assets/images/Total.png";
import completedicon from "../assets/images/Complete.png";
import onprogressicon from "../assets/images/Onprogress.png";
import pendingicon from "../assets/images/Pending.png";
import Navbar from "./Navbar";
import Sidebar from "./Sidebar";
import Footer from "./footer";
import AuthContext from "../../context/AuthProvider";

const decipher = (salt) => {
  const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
  const applySaltToChar = (code) =>
    textToChars(salt).reduce((a, b) => a ^ b, code);
  return (encoded) =>
    encoded
      .match(/.{1,2}/g)
      .map((hex) => parseInt(hex, 16))
      .map(applySaltToChar)
      .map((charCode) => String.fromCharCode(charCode))
      .join("");
};
const myDecipher = decipher("mySecretSalt");

function getItemFromLocal(localData) {
  let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
  return form_data;
}

function DashboardEM() {
  let local_data = getItemFromLocal("user_crypt");
  const employeeData = {
    EmployeeID: local_data.EmployeeID,
    EmployeeName: local_data.EmployeeName,
  };

  const [ReadData, setReadData] = useState([]);
  const {
    NotifyBadgeReadCount,
    setNotifyBadgeReadCount,
    NotificationID,
    setNotificationID,
    NotifyEMPname,
    setNotifyEMPname,
  } = useContext(AuthContext);
  setNotificationID(employeeData.EmployeeID);
  setNotifyBadgeReadCount(
    ReadData.reduce((sum, value) => sum + (value === 0), 0)
  );

  const FetchNotifyReadDATA = async () => {
    try {
      const NotifyReadDATA = { UserID: NotificationID };
      const response = await fetch("/fetchNotifyReadDATA", {
        method: "post",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(NotifyReadDATA),
      });
      const { data } = await response.json();
      setReadData(data === undefined ? [] : data.map((items) => items.IsRead));
    } catch (error) {
      console.error("error", error);
    }
  };
  
  FetchNotifyReadDATA();
  
  const [Data, setData] = useState({});

  async function fetchDataCount() {
    try {
      const response = await fetch(BaseUrl + "api/getCountsOfTaskData", {
        method: "POST",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(employeeData),
      });

      const { data } = await response.json();

      setData(data[0]);

    } catch (error) {
      console.error("error", error);
    }
  }

  useEffect(() => {
    fetchDataCount();
  }, []);

  return (
    <>
      <Navbar />
      <Sidebar />
      <div className="dashborad-employee-container">
        <div className="employee-welcome-prompt">
          Welcome {employeeData.EmployeeName},
        </div>

        <div className="employee-card-row">
          <div className="employee-card-column">
            <div className="employee-dashboard-content-left">
              <div className="employee-dashboard-img">
                <img
                  className="employee-image-style"
                  src={totalicon}
                  alt="pendingicon"
                />
              </div>
            </div>
            <div className="employee-dashboard-content-right">
              <div className="employee-dashboard-count">{Data.TotalCount}</div>
              <div className="employee-dashboard-contents">Total Tasks</div>
            </div>
          </div>

          <div className="employee-card-column">
            <div className="employee-dashboard-content-left">
              <div className="employee-dashboard-img">
                <img src={completedicon} alt="onprogressicon" />
              </div>
            </div>
            <div className="employee-dashboard-content-right">
              <div className="employee-dashboard-count">
                {Data.CompletedCount}
              </div>
              <div className="employee-dashboard-contents">Completed</div>
            </div>
          </div>

          <div className="employee-card-column">
            <div className="employee-dashboard-content-left">
              <div className="employee-dashboard-img">
                <img src={onprogressicon} alt="completedicon" />
              </div>
            </div>
            <div className="employee-dashboard-content-right">
              <div className="employee-dashboard-count">
                {Data.OnprogressCount}
              </div>
              <div className="employee-dashboard-contents">On Progress</div>
            </div>
          </div>

          <div className="employee-card-column">
            <div className="employee-dashboard-content-left">
              <div className="employee-dashboard-img">
                <img src={pendingicon} alt="totalicon" />
              </div>
            </div>
            <div className="employee-dashboard-content-right">
              <div className="employee-dashboard-count">
                {Data.PendingCount}
              </div>
              <div className="employee-dashboard-contents">Pending</div>
            </div>
          </div>
        </div>
      </div>
      <div className="report-footer">
        <Footer />
      </div>
    </>
  );
}

export default DashboardEM;
