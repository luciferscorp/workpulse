import { isDisabled } from '@testing-library/user-event/dist/utils'
import React from 'react'
import { useState } from 'react'
import '../assets/css/input.css'

const Input = (props) => {

  return (
    <div className='divison'>
      <input type={props.type} placeholder={props.placeholder} required={props.required} maxLength={props.maxLength} value={props.value} 
      className={props.classfield} onChange={(e)=>props.onChange(e)} min={props.minDate} max={props.maxDate} disabled={props.isDisabled}/>
    </div>
  )
}

export default Input;