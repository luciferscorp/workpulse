import React,{useState,useEffect} from "react";
import './../assets/css/StatusPopup.css';
// import Alert from '@mui/material/Alert';
// import Stack from '@mui/material/Stack';
import TaskAltIcon from '@mui/icons-material/TaskAlt';
export default function EditStatusPopup({ message, timeout }) {

  const [show, setShow] = useState(true);

  useEffect(() => {
    if (show) {
      const timer = setTimeout(() => {
        setShow(false);
        
      }, timeout);

      return () => {
        clearTimeout(timer);
      };
    }
  }, [show, ]);

  if (!show) {
    return null;
  }

  return <div className="auto-editclose-message ">{message}</div>;

};