import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../assets/css/AddProjects.css";
import "../assets/css/EditCompanyDetails.css";
import MultiselectDropdown from "multiselect-react-dropdown";

import Input from "./Input.js";
import Button from "./Button.js";
import { BaseUrl } from "../env/baseurl";
import DropDown from "./DropDown";


function EditCompanyDetails(props) {


  const [Name, setName] = useState(undefined);
  const [ID, setID] = useState(undefined);
  const [Status, setStatus] = useState(props.dataIn[0].isActive);

  useEffect(() => {
    setName(props.dataIn[0].CompanyName)
  }, []);

 

  let dataOut = {

    CompanyID: props.dataIn[0].CompanyID,
    CompanyName: Name,
    isActive: Status,

  }

  const ProjectValidation = (e) => {
    e.preventDefault();


    //api put function 
    async function updateCompFunction() {
      try {
        const updateUserData = dataOut;
        const response = await fetch(BaseUrl + "updateCompanyUsers", {
          method: "put",
          mode: "cors",
          cache: "no-cache",
          credentials: "same-origin",
          headers: {
            "Content-Type": "application/json",
          },
          redirect: "follow",
          referrerPolicy: "no-referrer",
          body: JSON.stringify(updateUserData),
        })
        const data = await response.json();
      

      }
      catch (error) { console.error("Error---", error); }
    }
    updateCompFunction()
    props.callback(new Date())
 
    props.clickDone();
    // props.clickClose();
  }



  return (
    <div className="edit-model-blur">
      <div className="project-container ">
        <div>
          <h3 className="project-reg-title">Edit Details</h3>
          <buttom
            className="project-popup-close-button"
            onClick={() => props.clickClose()}
          >
            &times;
          </buttom>
        </div>

        <Input
          type="text"
          id="project_name"
          value={Name}
          maxLength="30"
          classfield="project-inputField"
          // defaultValue={props.dataIn.content.Name}
          onChange={(e) => setName(e.target.value)}
        />


        <DropDown
          id="dropdown"
          classfield="edit-details-dropdown"
          Title="Change Status"
          values={["Active", "Disable"]}
          onChange={(e) => setStatus(e.target.value == "1" ? 0 : 1)}
        />

        <div>
          <Button
            type="button"
            Title="Done"
            classfield={"blue-submit-button"}
            onClick={ProjectValidation}
          />
        </div>
      </div>

    </div>
  );
}

export default EditCompanyDetails;
