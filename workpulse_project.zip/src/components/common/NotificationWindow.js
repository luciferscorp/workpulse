import { React, useState, useEffect, useContext } from 'react';
import "../assets/css/Notifications.css";
import moment from 'moment';
import CloseIcon from '@mui/icons-material/Close';
import AuthContext from '../../context/AuthProvider';
import Navbar from './Navbar';
import Sidebar from './Sidebar';
import Avatar from '@mui/material/Avatar';
import profile_image from '../assets/images/blank-profile-picture-30x30.webp';
import { useNavigate } from 'react-router-dom';


const decipher = (salt) => {
  const textToChars = text => text.split('').map(c => c.charCodeAt(0));
  const applySaltToChar = code => textToChars(salt).reduce((a, b) => a ^ b, code);
  return encoded => encoded.match(/.{1,2}/g)
    .map(hex => parseInt(hex, 16))
    .map(applySaltToChar)
    .map(charCode => String.fromCharCode(charCode))
    .join('');
}
const myDecipher = decipher('mySecretSalt')

function getItemFromLocal(localData) {
  let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
  return form_data;

}

export default function NotificationWindow(props) {

  let local_data = getItemFromLocal("user_crypt");
  const LoggedID = { EmployeeID: local_data.EmployeeID }

  const [createdDate, setCreatedDate] = useState([]);
  const [data, setdata] = useState([]);
  const [dataStatus, setdataStatus] = useState([]);
  const [differenceTime, setDifferenceTime] = useState([]);
  const [count, setcount] = useState(0);
  const [InitialTimeObj, setInitialTimeObj] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const navigate = useNavigate();
  const [NotifyType, setNotifyType] = useState([]);
  const [NotificationIDStatus, setNotificationIDStatus] = useState([]);
  const [ReadData, setReadData] = useState([]);
  const [ReadStatus, setReadStatus] = useState([]);
  const { NotifyBadgeReadCount, setNotifyBadgeReadCount, NotificationID, setNotificationID } = useContext(AuthContext);


  setNotificationID(LoggedID.EmployeeID);
  setNotifyBadgeReadCount(ReadData.reduce((sum, value) => sum + (value === 0), 0));

  async function NavigateNotifications() {
    if (NotifyType === "Leader Assign") {
      navigate("/leaderproject");
    }
    else if (NotifyType === "Member Assign") {
      navigate("/employeetasks");
    }
    else if (NotifyType === "Task Assign") {
      navigate("/employeetasks");
    }
    else if (NotifyType === "Project Completed") {
      navigate("/dashboardPM");
    }
    else if (NotifyType === "Task Completed") {
      navigate("/dashboardpl");
    }
    else if (NotifyType === "Comment") {
      navigate("/tasks");
    }
    else { }


  }

  const UpdateNotifyRead = async (readNotify, notifyID) => {
    try {
      const NotifyReadData = {
        IsRead: readNotify,
        NotifyID: notifyID
      }
      const response = await fetch("/updateISREAD", {
        method: "put",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(NotifyReadData),
      })
      const data = await response.json();
    } catch (error) {
      console.error("Error", error);
    }
  }

  const FindNotificationType = async () => {
    try {
      const NotifyData = await { NotificationID: NotificationIDStatus }
      const response = await fetch("/FindNotificationType", {
        method: "POST",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(NotifyData),
      })
      const data = await response.json();
      setNotifyType(data.data[0].NotificationType);

    } catch (error) {
      console.error("Error", error);
    }
  }


  const DeleteNotification = async (NotifyID) => {
    try {
      const DeleteData = { UserID: NotifyID }
      const response = await fetch("/updateIsDelete", {
        method: "put",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(DeleteData),
      })
      const data = await response.json();
    } catch (error) {
      console.error("Error", error);
    }
  }

  useEffect(() => {

    const FetchNotifyReadDATA = async () => {
      try {
        const NotifyReadDATA = { UserID: NotificationID };
        const response = await fetch("/fetchNotifyReadDATA", {
          method: "post",
          mode: "cors",
          cache: "no-cache",
          credentials: "same-origin",
          headers: {
            "Content-Type": "application/json",
          },
          redirect: "follow",
          referrerPolicy: "no-referrer",
          body: JSON.stringify(NotifyReadDATA),
        });
        const { data } = await response.json();
        setReadData(data === undefined ? [] : data.map((items) => (items.IsRead)));

      } catch (error) {
        console.error("error", error);
      }
    };

    const timeDifferenceToMinutesFromCurrent = (timeArray) => {
      const currentTime = new Date();
      const getDateDifference = (InitialDate, FinalDate, unit) => {
        const diffInMilliseconds = Math.abs(FinalDate - InitialDate);
        const diffInUnit = Math.floor(diffInMilliseconds / unit);
        return diffInUnit;
      };

      const differenceData = timeArray.map((currentDatefromFetch) => {
        const diffInMinutes = getDateDifference(currentDatefromFetch, currentTime, 60 * 1000);

        if (diffInMinutes < 1) {
          return 'just now';
        } else if (diffInMinutes < 60) {
          return diffInMinutes + ' minutes ago';
        } else if (diffInMinutes < 60 * 24) {
          const hours = Math.floor(diffInMinutes / 60);
          return hours + ' hours ago';
        } else if (diffInMinutes < 60 * 24 * 30) {
          const days = Math.floor(diffInMinutes / (60 * 24));
          return days + ' days ago';
        } else if (diffInMinutes < 60 * 24 * 30 * 12) {
          const diffInDays = getDateDifference(currentDatefromFetch, currentTime, 60 * 60 * 24 * 1000);
          const months = Math.floor(diffInDays / 30);
          return months + ' months ago';
        } else {
          return 'a long time ago';
        }
      });

      return differenceData;
    };

    const fetchNotificationData = async () => {
      try {
        const response = await fetch("/getNotifications", {
          method: "post",
          mode: "cors",
          cache: "no-cache",
          credentials: "same-origin",
          headers: {
            "Content-Type": "application/json",
          },
          redirect: "follow",
          referrerPolicy: "no-referrer",
          body: JSON.stringify(LoggedID),
        });
        const { data, status } = await response.json();
        setdata(data === undefined ? [] : data);
        setdataStatus(status);
        setCreatedDate(data.map((items) => (items.CreatedOn)));
      } catch (error) {
        console.error("error", error);
      }
    };

    fetchNotificationData();
    FetchNotifyReadDATA();
    FindNotificationType();
    NavigateNotifications();

    if (createdDate.length > 0) {
      const FormatTime = createdDate.map((time) => time.substring(11, 19));
      const FormatDate = createdDate.map((time) => time.substring(0, 10));
      const newInitialTimeObj = FormatDate.map((currentDatefromFetch, index) => {
        const utcTime = moment.utc(`${currentDatefromFetch}T${FormatTime[index]}`).toDate();
        const localTime = new Date(utcTime.getTime() + utcTime.getTimezoneOffset() * 60000);
        return localTime;
      });

      setInitialTimeObj(newInitialTimeObj);
      setDifferenceTime(timeDifferenceToMinutesFromCurrent(newInitialTimeObj));

    }
  }, [createdDate,]);


  return (
    <>

      <div className='notify-index'>
        <div className="notifiy-popup-wrapper">
          <div className="notifiy-popup-top-bar">
            <div className="notifiy-popup-title">
              <p className="notifiy-popup-title-text">Notifications</p>
            </div>
          </div>
          <div className="notifiy-popup-notifications">
            {dataStatus === 200 ? data.map((item, index) => (
              <div className={item.IsRead === 0 ? "notifiy-popup-single-box unseen" : "notifiy-popup-single-box unseenblue"} key={index}
                onClick={() => {
                  setNotificationIDStatus(item.NotificationID);
                  UpdateNotifyRead(1, item.NotificationID);
                }}>
                <div className="notifiy-popup-box-text">
                  <div className="notifiy-popup-notifi-time-wrapper">
                    <img src={item.ProfileImage == null ? profile_image : item.ProfileImage} />
                    <p className="notifiy-popup-notifi">{item.Content}</p>
                  </div>
                  <p className="notifiy-popup-time">{differenceTime[index]}</p>
                </div>
              </div>
            )) : <div className='notifiy-popup-no-notifications'>No Notifications</div>}
          </div>
          {dataStatus === 200 ? <div className='notifiy-popup-view-all'>
            <p><a href="/notifications">View all Notifications</a></p>
          </div> : ""}
        </div>
      </div>

    </>
  )
}