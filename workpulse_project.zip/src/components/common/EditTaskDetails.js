import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../assets/css/AddProjects.css";
import "../assets/css/EditCompanyDetails.css";
import MultiselectDropdown from "multiselect-react-dropdown";
import TimePickerComponent from "./TimePickerComponent";
import Input from "./Input.js";
import Button from "./Button.js";
import { BaseUrl } from "../env/baseurl";
import DropDown from "./DropDown";
import ErrorIcon from '@mui/icons-material/Error';



const currentDate = new Date();
const year = currentDate.getFullYear();
const month = String(currentDate.getMonth() + 1).padStart(2, '0');
const day = String(currentDate.getDate()).padStart(2, '0');
const hours = String(currentDate.getHours()).padStart(2, '0');
const minutes = String(currentDate.getMinutes()).padStart(2, '0');
const seconds = String(currentDate.getSeconds()).padStart(2, '0');
const setFormatDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

function EditTaskDetails(props) {

  const [Name, setName] = useState(undefined);
  const [Description, setDescription] = useState();
  const [EditDuration, setEditDuration] = useState("");
  const [Status, setStatus] = useState(props.dataIn[0].isActive);
  const [Assigned, setAssigned] = useState(props.dataIn[0].AssignedToEmployeeID?? []); 
  const [error, setError] = useState("");

  props.callbackDescription(Description);
  props.callbackDuration(EditDuration);


  useEffect(() => {
    setName(props.dataIn[0].ProjectName)
    setDescription(props.dataIn[0].TaskDescription)
  }, []);

  const ProjectValidation = (e) => {
    e.preventDefault();

    if (EditDuration === "") {
      setError("Set the duration");
    } else {
      setError("");
    let dataOut = {
      TaskID: props.dataIn[0].TaskID,
      TaskName: Name,
      EmployeeID: props.dataIn[0].EmployeeID,
      TaskDescription: Description,
      UpdateOn: setFormatDateTime,
    }
    async function updateTaskFunction() {
      try {
        const TaskProjectData = dataOut;
        const response = await fetch(BaseUrl + "TaskProjectData", {
          method: "put",
          mode: "cors",
          cache: "no-cache",
          credentials: "same-origin",
          headers: {
            "Content-Type": "application/json",
          },
          redirect: "follow",
          referrerPolicy: "no-referrer",
          body: JSON.stringify(TaskProjectData),
        })
        const { status } = await response.json();
      }
      catch (error) { console.error("Error", error); }
    }
    updateTaskFunction();
    props.callback(new Date());
    props.clickDone();
  }
  }


  return (
    <div className="edit-model-blur">
      <div className="project-container ">
        <div>
          <h3 className="project-reg-title">Edit Task</h3>
          <buttom
            className="project-popup-close-button"
            onClick={() => props.clickClose()}
          >
            &times;
          </buttom>
        </div>


        <textarea
          rows="6"
          placeholder="Describe the project here..."
          maxLength={150}
          form="usrform"
          value={Description}
          className="project-description"
          onChange={(e) => setDescription(e.target.value)}
        ></textarea>

        {Assigned.length!==0 && (<div>
          <TimePickerComponent
            handlechange={(e) => setEditDuration(e!=="" ? e.toString().split(" ")[4] : props.dataIn[0].DefaultDuration)}
          />
        </div>)}
        <span className="spanEnd" id="error">
       {error!=""? <ErrorIcon sx={{ fontSize: "18px" , position: "absolute",marginLeft:"-25px" }}/> :""} {error}
      </span>

        <div>
          <Button
            type="button"
            Title="Done"
            classfield={"blue-submit-button"}
            onClick={ProjectValidation}
          />
        </div>
      </div>

    </div>
  );
}

export default EditTaskDetails;