import { React, useState, useEffect, useContext } from 'react';
import '../assets/css/TaskPagination.css';
import { BaseUrl } from '../env/baseurl';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import DoneIcon from '@mui/icons-material/Done';
import TextField from '@mui/material/TextField';
import Button from "./Button.js";
import Input from "./Input.js";
import { Icon, IconButton } from '@mui/material';
import ConfirmDelete from './ConfirmDelete';
import AuthContext from '../../context/AuthProvider';
import EditTaskDetails from './EditTaskDetails';
import EditStatusPopup from './EditStatusPopup';
import dayjs from 'dayjs';



const decipher = (salt) => {
    const textToChars = text => text.split('').map(c => c.charCodeAt(0));
    const applySaltToChar = code => textToChars(salt).reduce((a, b) => a ^ b, code);
    return encoded => encoded.match(/.{1,2}/g)
        .map(hex => parseInt(hex, 16))
        .map(applySaltToChar)
        .map(charCode => String.fromCharCode(charCode))
        .join('');
}
const myDecipher = decipher('mySecretSalt')

function getItemFromLocal(localData) {
    let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
    return form_data;

}

const currentDate = new Date();
const year = currentDate.getFullYear();
const month = String(currentDate.getMonth() + 1).padStart(2, '0');
const day = String(currentDate.getDate()).padStart(2, '0');
const hours = String(currentDate.getHours()).padStart(2, '0');
const minutes = String(currentDate.getMinutes()).padStart(2, '0');
const seconds = String(currentDate.getSeconds()).padStart(2, '0');

const setFormatDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

const TaskPagination = (props) => {

    let local_data = getItemFromLocal("user_crypt")
    const projectleaderData = {
        EmployeeID: local_data.EmployeeID,
        EmployeeName: local_data.EmployeeName
    }

    const [currentPage, setCurrentPage] = useState(1);
    const [data, setdata] = useState([]);
    const [records, setrecords] = useState([]);
    const [totalPage, settotalPage] = useState();
    const [numbers, setnumbers] = useState([]);
    const [Companies, setCompanies] = useState();
    const recordPerPage = 5;
    const lastIndex = currentPage * recordPerPage;
    const firstIndex = lastIndex - recordPerPage;
    const [activeProjectId, setactiveProjectId] = useState(null);
    const [activeProjectName, setactiveProjectName] = useState("");
    const [activeProjectDescription, setactiveProjectDescription] = useState("");
    const [hide, setHide] = useState(false);
    const [hideEdit, setHideEdit] = useState(new Set());
    const [counter, setcounter] = useState(0);
    const [status, setstatus] = useState('');
    const [taskProjectLead, settaskProjectLead] = useState([])
    const [TaskIdCompare, setTaskIdCompare] = useState(0)
    const [AssignToEMPID, setAssignToEMPID] = useState([]);
    const [CreatedIDStatus, setCreatedIDStatus] = useState([]);
    const [TaskDesc, setTaskDesc] = useState([]);
    const [newpage, setnewpage] = useState(0);
    const [ProjectLeaderID, setProjectLeaderID] = useState([]);
    const [ReadData, setReadData] = useState([]);
    const { NotifyBadgeReadCount, setNotifyBadgeReadCount, NotificationID, setNotificationID, NotifyEMPname, setNotifyEMPname, DefaultValueOnTimer, setDefaultValueOnTimer} = useContext(AuthContext);
    const [isActive, setisActive] = useState(false);
    const [tobeDeleted, settobeDeleted] = useState("");
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isSaved, setisSaved] = useState(false)
    const [payload, setpayload] = useState('initialState');
    const [count, setcount] = useState(0);
    const [incrementCount, setIncrementCount] = useState(0);

    const [dataIn, setdataIn] = useState(undefined);
    const [TaskCreatedBy, setTaskCreatedBy] = useState([]);
    const [AssignedTaskName, setAssignedTaskName] = useState([]);
    const [activeEdit, setactiveEdit] = useState(false);
    const [fetchStatus, setfetchStatus] = useState("");
    const [DescFromEditTask, setDescFromEditTask] = useState('');
    const [DurationFromEditTask, setDurationFromEditTask] = useState('');
    

    const handleIncrementCount = () => {
        if (count > 0) {
          
          setcount(0);
        }
      
        setIncrementCount(incrementCount + 1);
    
      };
    const handleDescriptionCallback = (description) => {
        setDescFromEditTask(description);
    };
    const handleDurationCallback = (duration) => {
        setDurationFromEditTask(duration);
    };
    const callback = payload => {
        setfetchStatus(payload)
    }
    setNotificationID(projectleaderData.EmployeeID);
    setNotifyBadgeReadCount(ReadData.reduce((sum, value) => sum + (value === 0), 0));

    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = String(currentDate.getMonth() + 1).padStart(2, '0');
    const day = String(currentDate.getDate()).padStart(2, '0');
    const hours = String(currentDate.getHours()).padStart(2, '0');
    const minutes = String(currentDate.getMinutes()).padStart(2, '0');
    const seconds = String(currentDate.getSeconds()).padStart(2, '0');
    const setFormatDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

    function prePage() {
        if (currentPage !== 1) {
            setCurrentPage(currentPage - 1);
            setnewpage(newpage - recordPerPage);
        }
    }
    function changePage(newPage) {
        if (newPage !== currentPage) {
            setCurrentPage(newPage);
            setnewpage(0);
            if (newPage > numbers[0]) {
                setnewpage(newpage + recordPerPage);
            }
            if (newPage < numbers[0]) {
                setnewpage(newpage - recordPerPage);
            }
        }
    }
    function nextPage() {
        if (currentPage !== totalPage) {
            setCurrentPage(currentPage + 1);
            setnewpage(newpage + recordPerPage);
        }
    }
    function handleclick() {
        setisActive(true)
    }
    function handleclick_no() {
        setisActive(false)
    }
    function handleclick_yes() {
        deleteTaskRecord(tobeDeleted)
        fetchData()
        setisActive(false)
    }
    function handleclick_doneEdit() {
        if (AssignToEMPID !== undefined) {
            NotifyTaskUpdated(AssignToEMPID);
            NotifyUpdateDuration(AssignToEMPID);
            UpdateTaskDuration(CreatedIDStatus);
        }
        setactiveProjectId(!activeProjectId);
        setHide(!hide);
        setTaskIdCompare(false);
        setactiveEdit(false);   
        setisSaved(true);
        handleIncrementCount();
    }
    function handleclick_close() {
        setactiveProjectId(!activeProjectId);
        setHide(!hide);
        setTaskIdCompare(false);
        setactiveEdit(false)
    }
    async function fetchData() {
        try {
            const response = await fetch(BaseUrl + "api/getleaderstasks", {
                method: "POST",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(projectleaderData)
            });

            const { data } = await response.json();
            setdata(data === undefined ? [] : data);
            setrecords(data.slice(firstIndex, lastIndex));
            settotalPage(Math.ceil(data.length / recordPerPage));
            settaskProjectLead(data.map((items) => (items.ProjectLeader)));
        }
        catch (error) { console.error("error", error); }
    }
    const FetchNotifyReadDATA = async () => {
        try {
            const NotifyReadDATA = { UserID: NotificationID };
            const response = await fetch("/fetchNotifyReadDATA", {
                method: "post",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(NotifyReadDATA),
            });
            const { data } = await response.json();
            setReadData(data === undefined ? [] : data.map((items) => (items.IsRead)));

        } catch (error) {
            console.error("error", error);
        }
    };
    const NotifyTaskUpdated = async (AssignedToEmployeeID) => {
        try {
            const UpdateNewTask = await {
                UserID: AssignedToEmployeeID,
                TaskDescription: DescFromEditTask,
                ProjectLeaderName: NotifyEMPname,
                currentdate: setFormatDateTime,
                UpdatedBy: projectleaderData.EmployeeID,
                UpdatedOn: setFormatDateTime,
            };
            const response = await fetch("/notifyTaskUpdated", {
                method: "post",
                mode: "cors",
                cache: "no-cache",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                },
                redirect: "follow",
                referrerPolicy: "no-referrer",
                body: JSON.stringify(UpdateNewTask),
            });
            const { data } = await response.json();
        } catch (error) {
            console.error("error", error);
        }
    };
    async function NotifyUpdateDuration(AssignedToEmployeeID) {
        try {
          const DurationData = await {
            UserID : AssignedToEmployeeID,
            TaskName : AssignedTaskName,
            LeaderName : projectleaderData.EmployeeName,
            CreatedBy : TaskCreatedBy,
            CreatedOn : setFormatDateTime,
          };
          const response = await fetch("/NotifyUpdateDuration", {
            method: "post",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
              "Content-Type": "application/json",
            },
            redirect: "follow",
            referrerPolicy: "no-referrer",
            body: JSON.stringify(DurationData),
          })
          const { status } = await response.json();
        }
        catch (error) { console.error("Error", error); }
      }
    async function UpdateTaskDuration(TaskID) {
        try {
          const DurationTaskData = await {
            TaskID: TaskID,
            Duration : DurationFromEditTask,
          };
          const response = await fetch("/UpdateTaskDuration", {
            method: "put",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
              "Content-Type": "application/json",
            },
            redirect: "follow",
            referrerPolicy: "no-referrer",
            body: JSON.stringify(DurationTaskData),
          })
          const { status } = await response.json();
        }
        catch (error) { console.error("Error", error); }
      }
    useEffect(() => {
        FetchNotifyReadDATA();
        fetchData();
        setnumbers(Array.from({ length: totalPage }, (_, index) => index + 1));
    }, [currentPage, totalPage, fetchStatus]);

    useEffect(() => {
        setTimeout(() => {
            fetchData();
        }, 400);
    }, [props.doFetch, fetchStatus]);
    async function deleteTaskRecord(taskDeleteParam) {

        try {
            const deleteTaskData = { id: taskDeleteParam };
            const response = await fetch(BaseUrl + 'deleteTaskData', {
                method: "put",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(deleteTaskData),
            });
            const data = await response.json();

        } catch (error) {
            console.error("error", error);
        }
    }

    return (
        <>  <div className='task-prj-Status-popup'>
        {isSaved && (<EditStatusPopup message={"successfully Edited!"} timeout={2000}  handleIncrementCount={handleIncrementCount}  />)}
     </div>
            {data === undefined || data.length == 0 ? <div className='task-prj-tablecontainer'><h2>No Task have been created yet</h2></div> :

                <div className="task-prj-bodycontainer">
                    <div className='task-prj-tablecontainer'>
                        <table className="task-prj-tablecontent">
                          
                            <thead >
                                <th className='task-prj-tablehead task-prj-tablehead-sno'>S.No</th>
                                <th className='task-prj-tablehead task-prj-tablehead-pname'>Project Name</th>
                                <th className='task-prj-tablehead task-prj-tablehead-tname'>Task Name</th>
                                <th className='task-prj-tablehead task-prj-tablehead-desc'>Description</th>
                                <th className='task-prj-tablehead task-prj-tablehead-duration'>Duration</th>
                                <th className='task-prj-tablehead task-prj-tablehead-action'>Action</th>
                            </thead>
                            <tbody className='task-prj-tablebody'>
                                {records.map((ArrayData, i) => (
                                    <tr className='task-prj-tablerow' key={i}>
                                        {/* project name  */}
                                        <td className='task-prj-tabledata'>{i + 1 + newpage}</td>
                                        <td className='task-prj-tabledata'>{ArrayData.ProjectName}</td>
                                        {/* Task name  */}
                                        <td className='task-prj-tabledata'>{ArrayData.TaskName}</td>

                                        {/* project description */}
                                        <td className=' task-prj-description'>
                                            {ArrayData.TaskDescription}
                                        </td>
                                        <td className=' task-prj-description'>
                                            {ArrayData.Duration===null ? "Not assigned":ArrayData.Duration}
                                        </td>
                                        {/* action field  */}
                                        <td className='cmp-tabledata'>
                                            {ArrayData.TaskID !== activeProjectId &&
                                                <IconButton disabled={TaskIdCompare ? true : false} sx={{ color: "#54B4D3" }}>
                                                    <EditIcon sx={{ cursor: "pointer" }}
                                                        onClick={() => {
                                                            setTaskIdCompare(ArrayData.TaskID);
                                                            setactiveProjectId(ArrayData.TaskID);
                                                            setactiveProjectDescription(ArrayData.TaskDescription);
                                                            setHide(!hide);
                                                            setHideEdit(hideEdit.add(ArrayData.TaskTaskID));
                                                            setcounter(counter + 1);
                                                            setNotifyEMPname(projectleaderData.EmployeeName);
                                                            setAssignedTaskName(ArrayData.TaskName);
                                                            setTaskCreatedBy(ArrayData.CreatedBy);
                                                            const defaultDuration = ArrayData.Duration !== null ? dayjs(`2022-04-17T${ArrayData.Duration}`) : dayjs('2022-04-17T00:00:00');
                                                            setDefaultValueOnTimer(defaultDuration);
                                                            setdataIn([
                                                                {
                                                                    TaskID: ArrayData.TaskID,
                                                                    TaskName: ArrayData.TaskName,
                                                                    TaskDescription: ArrayData.TaskDescription,
                                                                    EmployeeID: projectleaderData.EmployeeID,
                                                                    AssignedToEmployeeID: ArrayData.AssignedToEmployeeID,
                                                                    CreatedBy: ArrayData.CreatedBy,
                                                                    Duration: DefaultValueOnTimer,
                                                                    DefaultDuration : ArrayData.Duration
                                                                }
                                                            ]
                                                            )
                                                            setactiveEdit(true);
                                                            setcount(count + 1);
                                                            setisSaved(false);
                                                            if (ArrayData.AssignedToEmployeeID === null) {
                                                                setAssignToEMPID();
                                                                setCreatedIDStatus();
                                                            }
                                                            else if (ArrayData.AssignedToEmployeeID !== null) {
                                                                setAssignToEMPID(ArrayData.AssignedToEmployeeID);
                                                                setCreatedIDStatus(ArrayData.TaskID);
                                                            }
                                                        }} />
                                                </IconButton>}

                                            {hide && ArrayData.TaskID === activeProjectId &&
                                                (<DoneIcon sx={{ cursor: "pointer", color: "#5cb85c" }}
                                                    onClick={() => {
                                                        setactiveProjectId(!ArrayData.TaskID);
                                                        setactiveProjectDescription(ArrayData.TaskDescription);
                                                        setHide(!hide);
                                                        setTaskIdCompare(false);
                                                        fetchData();
                                                    }} />)}

                                            {ArrayData.ProjectID &&
                                                <IconButton sx={{ color: "#DC3545" }}>
                                                    <DeleteIcon sx={{ cursor: "pointer", marginLeft: "5px" }} onClick={() => {
                                                        handleclick();
                                                        settobeDeleted(ArrayData.TaskID)
                                                    }} />
                                                </IconButton>}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    {isActive && <ConfirmDelete content={"project"} clickNo={() => handleclick_no()} clickYes={() => handleclick_yes()} />}
                    {activeEdit && <EditTaskDetails
                        dataIn={dataIn}
                        clickClose={() => handleclick_close()}
                        clickDone={() => handleclick_doneEdit()}
                        callbackDescription={handleDescriptionCallback}
                        callbackDuration={handleDurationCallback}
                        callback={callback}
                    />}
                    
                </div>}

            {data === undefined || data.length == 0 ? "" :
                <div className='task-prj-navbar'>
                    <ul className='task-prj-pagination'>
                        <li className='task-prj-page-item'>
                            <a href='#' className='task-prj-page-link' onClick={prePage}>Prev</a>
                        </li>
                        {
                            numbers.map((n, i) => (
                                <li className={`task-prj-page-item ${currentPage === n ? 'active' : ''}`} key={i}>
                                    <a href='#' className='task-prj-page-link' onClick={() => changePage(n)}>{n}</a>
                                </li>
                            ))
                        }
                        <li className='task-prj-page-item'>
                            <a href='#' className='task-prj-page-link' onClick={nextPage}>Next</a>
                        </li>
                    </ul>
                </div>}
        </>
    )



}

export default TaskPagination;