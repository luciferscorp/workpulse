import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from "react-router-dom";
import '../assets/css/AdminReportPagination.css';
import { BaseUrl } from '../env/baseurl';
import DownloadPDF from './DownloadPDF';
import DropDown from './DropDown';
import Input from './Input';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import Button from './Button';

import clearfilter_icon from "../assets/images/ClearFilters.png"


const decipher = (salt) => {
  const textToChars = text => text.split('').map(c => c.charCodeAt(0));
  const applySaltToChar = code => textToChars(salt).reduce((a, b) => a ^ b, code);
  return encoded => encoded.match(/.{1,2}/g)
    .map(hex => parseInt(hex, 16))
    .map(applySaltToChar)
    .map(charCode => String.fromCharCode(charCode))
    .join('');
}
const myDecipher = decipher('mySecretSalt')

function getItemFromLocal(localData) {
  let form_data = JSON.parse(myDecipher(localStorage.getItem(localData)));
  return form_data;

}

const AdminReportPagination = (props) => {

  const navigate = useNavigate();

  // let local_data = getItemFromLocal("user_crypt")
  // const projectleaderData = {
  //     EmployeeID: local_data.EmployeeID
  // }
  const [isTaskFound, setisTaskFound] = useState(true);

  const [currentPage, setCurrentPage] = useState(1);
  const [data, setdata] = useState([]);
  const [records, setrecords] = useState([]);
  const [totalPage, settotalPage] = useState();
  const [numbers, setnumbers] = useState([]);
  const recordPerPage = 5;
  const lastIndex = currentPage * recordPerPage;
  const firstIndex = lastIndex - recordPerPage;
  const [taskProjectLead, settaskProjectLead] = useState([])
  const [TaskIdCompare, setTaskIdCompare] = useState(0)
  let taskcurrentDateRaw = new Date()
  let taskupdateDate = taskcurrentDateRaw.toISOString().split('T')[0].split("-").reverse().join("/");
  const [newpage, setnewpage] = useState(0);
  const [employeesName, setEmployeesName] = useState([]);
  const [allProject, setAllProject] = useState([]);
  const [startDate, setStartDate] = useState(undefined);
  const [endDate, setEndDate] = useState(undefined);

  const Status = useRef(undefined)
  const EmployeeID = useRef(undefined)
  const ProjectID = useRef(undefined)
  const StartDate = useRef(undefined)
  const EndDate = useRef(undefined)

  const [currentStauts, setcurrentStauts] = useState(undefined);



  let Employees = employeesName.map((items) => (items.EmployeeName))
  let employeeIDs = employeesName.map((items) => (items.EmployeeID))


  let projects = allProject.map((items) => (items.ProjectName))
  let projectIDs = allProject.map((items) => (items.ProjectID))


  const [payload, setpayload] = useState("initialState");
  const callbacktable = payload => {
    setpayload(payload)
  }

  const convertDateString = (dateString) => {
    return dateString.split("-").reverse().join("/")
  }


  function prePage() {
    if (currentPage !== 1) {
      setCurrentPage(currentPage - 1);
      setnewpage(newpage - recordPerPage);
    }
  }
  function changePage(newPage) {
    if (newPage !== currentPage) {
      setCurrentPage(newPage);
      setnewpage(0);
      if (newPage > numbers[0]) {
        setnewpage(newpage + recordPerPage);
      }
      if (newPage < numbers[0]) {
        setnewpage(newpage - recordPerPage);
      }
    }
  }
  function nextPage() {
    if (currentPage !== totalPage) {
      setCurrentPage(currentPage + 1);
      setnewpage(newpage + recordPerPage);
    }
  }

  async function fetchAssignedTasks() {
    try {

      const response = await fetch(BaseUrl + "api/getAdminReportEmpnames", {
        method: "GET",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
      });

      const { status } = await response.json();
      // setEmployeesName(data == null ? [] : data)
      setisTaskFound(status != 300 ? false : true);

    }
    catch (error) { console.error("error", error); }
  }

  //api get function 
  async function fetchData(dropdownid, employeeID, projectID, startDate, endDate) {

    const updateDropdownData = {
      StatusID: dropdownid,
      EmployeeID: employeeID,
      ProjectID: projectID,
      StartDate: startDate,
      EndDate: endDate
    }

    try {
      const response = await fetch("getallTasksAdminReport", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(updateDropdownData)
      });

      const { data, status } = await response.json();
      setdata(data);


      setrecords(data.slice(firstIndex, lastIndex));
      settotalPage(Math.ceil(data.length / recordPerPage));
      settaskProjectLead(data.map((items) => (items.ProjectLeader)));
    }
    catch (error) { console.error("error", error); }
  }

  useEffect(() => {
    fetchData(Status.current, EmployeeID.current, ProjectID.current, StartDate.current, EndDate.current)
  }, []);


  //DropDown data
  async function fetchEmployeeData() {
    try {

      const response = await fetch(BaseUrl + "api/getAdminReportEmpnames", {
        method: "GET",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
      });

      const { data } = await response.json();
      setEmployeesName(data == null ? [] : data)

    }
    catch (error) { console.error("error", error); }
  }

  //DropDown data
  async function fetchProjectData() {
    try {
      const response = await fetch(BaseUrl + "getallprojects", {
        method: "GET",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
      });

      const { data } = await response.json();
      setAllProject(data == null ? [] : data)

    }
    catch (error) { console.error("error", error); }
  }

  useEffect(() => {
    fetchAssignedTasks()
    fetchEmployeeData()
    fetchProjectData()
  }, []);

  useEffect(() => {
    fetchData(Status.current, EmployeeID.current, ProjectID.current, StartDate.current, EndDate.current)
    setnumbers(Array.from({ length: totalPage }, (_, index) => index + 1));
  }, [currentPage, totalPage]);

  useEffect(() => {

    setTimeout(() => {
      fetchData(Status.current, EmployeeID.current, ProjectID.current, StartDate.current, EndDate.current)
    }, 400);
  }, [props.doFetch]);


  const clearFilter = () => {
    Status.current = undefined;
    EmployeeID.current = undefined;
    ProjectID.current = undefined;
    StartDate.current = undefined;
    EndDate.current = undefined;
    Employees = [];
    projects = [];
    // fetchEmployeeData()
    // fetchProjectData()
    document.getElementById("activeStatus").selectedIndex = 0;
    document.getElementById("dropdown").selectedIndex = 0;
    document.getElementById("dropdown-project-name").selectedIndex = 0;
    fetchData();

  }



  return (
    <>
      {isTaskFound == true ?
        <div className="AdminReport-bodycontainer">
          <div className='AdminReport-tablecontainer-text'>
            <h2>No Records found</h2>
          </div>
        </div>
        :
        <div className="AdminReport-bodycontainer">
          <div className="adminreport-overall-options">


            <div className='AdminReport-Dropdown'>

              <div className="adminreport-filter-div">
                <span>Task Status</span>
                <select className='Admin-Status-dropdown' id="activeStatus" name="status"
                  aria-placeholder="Active" active="select"
                  onChange={(e) => {
                    Status.current = e.target.value
                    fetchData(Status.current, EmployeeID.current, ProjectID.current, StartDate.current, EndDate.current)

                  }}>
                  <option className='Admin-Status-dropdown-content' value="none" disabled selected hidden>Filter by Status</option>
                  <option className='Admin-Status-dropdown-content' value='1'>Pending</option>
                  <option className='Admin-Status-dropdown-content' value="2">OnProgress</option>
                  <option className='Admin-Status-dropdown-content' value="3">Completed</option>
                  <option className='Admin-Status-dropdown-content' value="4">Delayed</option>
                </select>
              </div>
              <div className="adminreport-filter-div">
                <span>Members</span>
                <DropDown id="dropdown" classfield="Admin-Status-dropdown" Title="Filter by Member"
                  values={Employees}
                  onChange={(e) => {
                    EmployeeID.current = employeeIDs[e.target.value];
                    fetchData(Status.current, EmployeeID.current, ProjectID.current, StartDate.current, EndDate.current)
                  }}
                />
              </div>
              <div className="adminreport-filter-div">
                <span>Projects</span>
                <DropDown id="dropdown-project-name" classfield="Admin-Status-dropdown" Title="Filter by Project Name"
                  values={projects}
                  onChange={(e) => {
                    ProjectID.current = projectIDs[e.target.value];
                    fetchData(Status.current, EmployeeID.current, ProjectID.current, StartDate.current, EndDate.current)
                  }}
                />

              </div>
              <div className="adminreport-filter-div">
                <span>From</span>
                <Input type="date" placeholder="Start Date" classfield="startdate-filter-inputField"
                  onChange={(e) => {
                    StartDate.current = e.target.value
                    fetchData(Status.current, EmployeeID.current, ProjectID.current, e.target.value, EndDate.current)
                  }}

                  required />

              </div>
              <div className="adminreport-filter-div">
                <span>To</span>
                <Input type="date" placeholder="End Date" classfield="enddate-filter-inputField" minDate={StartDate.current}
                  isDisabled={StartDate.current != undefined ? false : true}
                  onChange={(e) => {

                    EndDate.current = e.target.value;
                    fetchData(Status.current, EmployeeID.current, ProjectID.current, StartDate.current, EndDate.current);

                  }} required />

              </div>
              <div className="adminreport-filter-div">

                <Button classfield={"clear-filter-button"}
                  type="button"
                  Title={<img src={clearfilter_icon} className="adminreport-clear-filter-img" />}
                  onClick={clearFilter
                  }
                />

              </div>
            </div>
          </div>

          {data === undefined || data.length == 0 ? <div className="AdminReport-bodycontainer">
            <div className='AdminReport-tablecontainer-text'>
              <h2>No Records found</h2>
            </div>
          </div>
            :
            <div className="pagination-flex-table-navbar">
              <div className='AdminReport-tablecontainer'>
                <table className="AdminReport-tablecontent">
                  {/* <h4 className='TaskPagination-heading' >Task Details</h4> */}
                  <thead>
                    <th className='AdminReport-tablehead'>S.No</th>
                    <th className='AdminReport-tablehead'>Project Name</th>
                    <th className='AdminReport-tablehead'>Task Name</th>
                    <th className='AdminReport-tablehead'>Task Description</th>
                    <th className='AdminReport-tablehead '>CreatedOn</th>
                    <th className='AdminReport-tablehead '>Project Leader</th>
                    <th className='AdminReport-tablehead '>Assign By</th>
                    <th className='AdminReport-tablehead'>Duration</th>
                    {/* <th className='AdminReport-tablehead'>StartTime</th> */}
                    {/* <th className='AdminReport-tablehead'>EndTime</th> */}
                    <th className='AdminReport-tablehead '>Status</th>
                  </thead>
                  <tbody className='AdminReport-tablebody'>
                    {records.map((ArrayData, i) => (
                      <tr className='AdminReport-tablerow' key={i}>
                        {/* project name  */}
                        <td className='AdminReport-tabledata'>{i + 1 + newpage}</td>
                        {/* Task name  */}
                        <td className='AdminReport-tabledata'>{ArrayData.ProjectIDName}</td>
                        <td className='AdminReport-tabledata'>{ArrayData.TaskName}</td>
                        {/* project description */}
                        <td className='AdminReport-description'>{ArrayData.TaskDescription}</td>
                        <td className=' AdminReport-tabledata'>{ArrayData.CreatedOn}</td>
                        <td className=' AdminReport-tabledata'>{ArrayData.CreatedByName}</td>
                        <td className={` AdminReport-tabledata ${ArrayData.Duration == null ? "AdminReport-null" : " "}`}>{ArrayData.EmployeeName == null ? "-" : ArrayData.EmployeeName}</td>
                        <td className={` AdminReport-tabledata ${ArrayData.Duration == null ? "AdminReport-null" : " "}`}>{ArrayData.Duration == null ? "-" : ArrayData.Duration}</td>
                        {/* <td className={` AdminReport-tabledata ${ArrayData.StartTime == null ? "AdminReport-null" : " "}`}>{ArrayData.StartTime== null ? "-" :ArrayData.StartTime}</td> */}
                        {/* <td className={` AdminReport-tabledata ${ArrayData.EndTime == null ? "AdminReport-null" : " "}`}>{ArrayData.EndTime== null ? "-" :ArrayData.EndTime}</td> */}
                        <td className=' AdminReport-tabledata AdminReport-tablehead-status'>
                          {ArrayData.TaskStatusID <= 1 ? <div className='Admin-Report-pending-div'><span className='Admin-Report-pending'>Pending</span></div> :
                            ArrayData.TaskStatusID === 2 ? <div className='Admin-Report-pending-div'> <span className='Admin-Report-OnProgress'>On Progress</span> </div> :
                              ArrayData.TaskStatusID === 4 || ArrayData.TaskStatusID === 5 ? <span className='Admin-Report-Delayed'>Delayed</span> :
                                ArrayData.TaskStatusID === 3 ? <span className='Admin-Report-Completed'>Completed</span> :

                                  "Something wrong"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className='AdminReport-navbar'>
                
          <div className="adminreport-download-button">
            <DownloadPDF tobedownloaded={data} role={1} />
          </div>
                <ul className='AdminReport-pagination'>
                  <li className='AdminReport-page-item'>
                    <a href='#' className='AdminReport-page-link' onClick={prePage}>Prev</a>
                  </li>
                  {
                    numbers.map((n, i) => (
                      <li className={`AdminReport-page-item ${currentPage === n ? 'active' : ''}`} key={i}>
                        <a href='#' className='AdminReport-page-link' onClick={() => changePage(n)}>{n}</a>
                      </li>
                    ))
                  }
                  <li className='AdminReport-page-item'>
                    <a href='#' className='AdminReport-page-link' onClick={nextPage}>Next</a>
                  </li>
                </ul>
              </div>
            </div>
          }
        </div>
      }



    </>
  )



}

export default AdminReportPagination;